@echo off
rem =========================================================================
rem  Alchemy HPET Package - launcher 3 of 3
rem  THE COMPLETE GUIDED TEST. Applies each scenario, measures it, and
rem  restores the Windows default at the end. It saves its progress, so
rem  simply run this SAME file again after every restart until it says
rem  TEST COMPLETE.
rem =========================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Complete-Test.ps1" %*
