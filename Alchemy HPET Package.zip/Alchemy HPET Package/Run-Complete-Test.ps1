<#
================================================================================
 Run-Complete-Test.ps1   |   Alchemy Tweaks - HPET Debunk Package
================================================================================
 WHAT THIS IS
   A guided, step-by-step runner for the WHOLE test matrix. You do not need
   to remember any commands - just run this file, follow the messages, and
   run it AGAIN after every restart until it says TEST COMPLETE.

 WHAT IT DOES, IN ORDER
   1. BASELINE FIRST, ALWAYS. It checks the timer settings your Windows has
      right now. If they are already the clean Windows default, that IS your
      baseline. If any timer override is set (so your system is NOT original),
      it applies the universal Windows default first - to be sure the baseline
      is a true baseline - and asks for one restart.
   2. Measures the baseline with the read-only speed test (Measure-Timer-Speed).
   3. For each scenario: applies it, asks you to restart, verifies after the
      restart that the scenario is really active, then measures it.
   4. When every scenario is measured, it RESTORES the clean Windows default
      and shows a comparison table of all results.

 SCENARIOS TESTED (default: all four)
   PlatformClock  -> bcdedit /set useplatformclock yes    (the core HPET myth)
   DynamicTick    -> bcdedit /set disabledynamictick yes
   PlatformTick   -> bcdedit /set useplatformtick yes
   FullMyth       -> all three of the above at once

 SAFETY
   - Every change goes through Change-Timer-Settings.ps1, which ALWAYS takes
     a timestamped BCD backup first (folder: AlchemyHPET).
   - Everything is fully reversible; the final step restores the default.
   - Progress is saved in TestPlan.json next to this script, so the test
     survives restarts. Delete it (or use -Reset) to start over.
   - It never restarts your PC without asking you first.

 USAGE (easiest: double-click RUN-3_Complete-Auto-Test.cmd)
   powershell -ExecutionPolicy Bypass -File .\Run-Complete-Test.ps1

 OPTIONS (advanced, all optional)
   -Scenarios    comma-separated subset, e.g. "PlatformClock,FullMyth".
                 The word None = measure the baseline only.
   -Repetitions  benchmark repetitions per state (default 5)
   -Reset        forget saved progress and restore the Windows default
   -NoPause      do not wait for Enter before the window closes
================================================================================
#>

[CmdletBinding()]
param(
    [string] $Scenarios   = "PlatformClock,DynamicTick,PlatformTick,FullMyth",

    [ValidateRange(1, 50)]
    [int]    $Repetitions = 5,

    [switch] $Reset,
    [switch] $NoPause,

    # Internal marker: set automatically when the script relaunches itself
    # elevated. Do not pass it yourself.
    [Parameter(DontShow)]
    [switch] $Elevated
)

$ErrorActionPreference = "Stop"

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Exit-Script([int]$code) {
    if (-not $NoPause) {
        Write-Host ""
        Read-Host " Press Enter to close this window" | Out-Null
    }
    exit $code
}

# ---------------------------------------------------------------------------
# Self-elevation
# ---------------------------------------------------------------------------
if (-not (Test-Admin)) {
    Write-Host ""
    Write-Host " This tool needs Administrator rights. Requesting elevation..." -ForegroundColor Yellow
    $psExe = if ($PSVersionTable.PSEdition -eq "Core") { "pwsh.exe" } else { "powershell.exe" }
    $argList = @("-NoProfile","-ExecutionPolicy","Bypass","-File", ('"{0}"' -f $PSCommandPath))
    foreach ($kv in $PSBoundParameters.GetEnumerator()) {
        if ($kv.Value -is [System.Management.Automation.SwitchParameter]) {
            if ($kv.Value) { $argList += ("-{0}" -f $kv.Key) }
        } else {
            $argList += ("-{0}" -f $kv.Key)
            $argList += ('"{0}"' -f $kv.Value)
        }
    }
    $argList += "-Elevated"
    try {
        Start-Process -FilePath $psExe -Verb RunAs -ArgumentList ($argList -join " ") | Out-Null
        Write-Host " Elevated window launched. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        Write-Host " Elevation was declined. Nothing was changed." -ForegroundColor Red
        Exit-Script 1
    }
}

Set-Location -LiteralPath $PSScriptRoot
$ChangeTool  = Join-Path $PSScriptRoot "Change-Timer-Settings.ps1"
$MeasureTool = Join-Path $PSScriptRoot "Measure-Timer-Speed.ps1"
$PlanPath    = Join-Path $PSScriptRoot "TestPlan.json"
$ResultsDir  = Join-Path $PSScriptRoot "qpc_results"

foreach ($tool in @($ChangeTool, $MeasureTool)) {
    if (-not (Test-Path -LiteralPath $tool)) {
        Write-Host " ERROR: missing companion script: $tool" -ForegroundColor Red
        Write-Host " Keep all package files together in the same folder." -ForegroundColor Red
        Exit-Script 1
    }
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
$AllScenarios = @("PlatformClock","DynamicTick","PlatformTick","FullMyth")
$timerOptions = @("useplatformclock","useplatformtick","disabledynamictick","tscsyncpolicy")

# Which BCD options each state is expected to have set to Yes (all others unset).
$ExpectedYes = @{
    "Default"       = @()
    "PlatformClock" = @("useplatformclock")
    "DynamicTick"   = @("disabledynamictick")
    "PlatformTick"  = @("useplatformtick")
    "FullMyth"      = @("useplatformclock","disabledynamictick","useplatformtick")
}

function Invoke-Bcdedit([string[]]$BcdArgs) {
    $eap = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $out  = & bcdedit @BcdArgs 2>&1
        $code = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $eap
    }
    $text = @($out | ForEach-Object { "$_" }) -join [Environment]::NewLine
    return [pscustomobject]@{ ExitCode = $code; Output = $text }
}

# Returns the list of timer options currently SET in the BCD (empty = default).
function Get-SetTimerOptions {
    $res = Invoke-Bcdedit @("/enum","{current}")
    if ($res.ExitCode -ne 0) { throw "bcdedit /enum failed: $($res.Output)" }
    $lines = $res.Output -split "\r?\n"
    $set = @()
    foreach ($opt in $timerOptions) {
        if ($lines | Where-Object { $_ -match ("^\s*{0}\s+\S" -f [regex]::Escape($opt)) }) { $set += $opt }
    }
    return $set
}

function Test-StateActive([string]$state) {
    $set = @(Get-SetTimerOptions)
    $exp = @($ExpectedYes[$state])
    if ($set.Count -ne $exp.Count) { return $false }
    foreach ($o in $exp) { if ($set -notcontains $o) { return $false } }
    return $true
}

function Get-BootTimeUtc {
    return (Get-CimInstance -ClassName Win32_OperatingSystem).LastBootUpTime.ToUniversalTime()
}

function Save-Plan($plan) {
    $plan | ConvertTo-Json -Depth 6 | Out-File -FilePath $PlanPath -Encoding utf8
}

function Invoke-ChildScript([string]$file, [string[]]$childArgs) {
    # Out-Host shows the child's output live WITHOUT feeding it into this
    # function's return value - only the exit code is returned.
    & powershell -NoProfile -ExecutionPolicy Bypass -File $file @childArgs | Out-Host
    return $LASTEXITCODE
}

function Set-TimerState([string]$state) {
    Write-Host ""
    Write-Host (" >>> Setting boot timer state: {0} (backup is taken automatically)" -f $state) -ForegroundColor Yellow
    if ($state -eq "Default") { $childArgs = @("-Action","Revert","-Force","-NoPause") }
    else                      { $childArgs = @("-Action","Apply","-State",$state,"-Force","-NoPause") }
    $code = Invoke-ChildScript $ChangeTool $childArgs
    if ($code -ne 0) { throw "Change-Timer-Settings.ps1 failed (exit $code). Stopping - review the output above." }
}

function Invoke-Benchmark([string]$label) {
    Write-Host ""
    Write-Host (" >>> Measuring timer read cost - state '{0}' ({1} repetitions)..." -f $label, $Repetitions) -ForegroundColor Yellow
    $childArgs = @("-Label",$label,"-Repetitions","$Repetitions","-OutDir",$ResultsDir,"-NoElevate","-NoPause")
    $code = Invoke-ChildScript $MeasureTool $childArgs
    if ($code -ne 0) { throw "Measure-Timer-Speed.ps1 failed (exit $code)." }
    $csv = Get-ChildItem -Path $ResultsDir -Filter ("qpc_{0}_*.csv" -f $label) |
           Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $csv) { throw "Benchmark CSV for label '$label' was not found in $ResultsDir." }
    return $csv.FullName
}

function Request-Reboot([string]$why) {
    Write-Host ""
    Write-Host " *** RESTART REQUIRED *** $why" -ForegroundColor Magenta
    Write-Host " After the PC restarts, run RUN-3_Complete-Auto-Test.cmd AGAIN to continue." -ForegroundColor Magenta
    $ans = Read-Host " Restart NOW? Type YES to restart, anything else to restart later yourself"
    if ($ans -ceq "YES") {
        Write-Host " Restarting in 5 seconds... (Ctrl+C to abort)" -ForegroundColor Red
        Start-Sleep -Seconds 5
        Restart-Computer -Force
        exit 0
    }
    Write-Host " OK - restart manually, then run this tool again to continue." -ForegroundColor Yellow
    Write-Host " Use RESTART, not Shut down: with Windows Fast Startup enabled," -ForegroundColor Yellow
    Write-Host " 'Shut down + power on' is NOT a full boot and BCD changes may not apply." -ForegroundColor Yellow
    Exit-Script 0
}

function Get-CsvSummaryValue([string]$csvPath, [string]$metric) {
    $line = Get-Content -LiteralPath $csvPath | Where-Object { $_ -match ("^summary,.*,{0}," -f [regex]::Escape($metric)) } | Select-Object -First 1
    if ($line) { return [double](($line -split ",")[4]) }
    return $null
}

function Show-FinalSummary($plan) {
    Write-Host ""
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host " FINAL COMPARISON - timer read cost per state" -ForegroundColor Cyan
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host (" {0,-26} {1,14} {2,18} {3,12}" -f "State (label)","ns/call","multi calls/sec","gain") -ForegroundColor Green
    $rows = @()
    foreach ($s in @($plan.steps)) {
        if (-not $s.Csv -or -not (Test-Path -LiteralPath $s.Csv)) { continue }
        $ns   = Get-CsvSummaryValue $s.Csv "single_median_ns"
        $cps  = Get-CsvSummaryValue $s.Csv "multi_median_cps"
        $gain = Get-CsvSummaryValue $s.Csv "concurrency_gain_x"
        Write-Host (" {0,-26} {1,14:N2} {2,18:N0} {3,11:N2}x" -f $s.Label, $ns, $cps, $gain)
        $rows += ('"{0}",{1},{2},{3}' -f $s.Label, $ns, $cps, $gain)
    }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $outCsv = Join-Path $ResultsDir ("COMPARISON_{0}.csv" -f $stamp)
    @('label,single_median_ns,multi_median_cps,concurrency_gain_x') + $rows |
        Out-File -FilePath $outCsv -Encoding utf8
    Write-Host ""
    Write-Host (" Comparison CSV: {0}" -f $outCsv) -ForegroundColor Green
    Write-Host " Higher ns/call and gain <= ~1x in a forced state, with the baseline" -ForegroundColor Magenta
    Write-Host " fast and gaining above 1x, is the direct evidence of what forcing the" -ForegroundColor Magenta
    Write-Host " platform clock really does to the timer path on this machine." -ForegroundColor Magenta
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
try {
    Write-Host ""
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host " Alchemy - Complete HPET Test (guided, resumable)" -ForegroundColor Cyan
    Write-Host "==============================================================" -ForegroundColor Cyan

    # ----- Reset -----
    if ($Reset) {
        Write-Host " Reset requested: forgetting saved progress and restoring defaults." -ForegroundColor Yellow
        if (Test-Path -LiteralPath $PlanPath) { Remove-Item -LiteralPath $PlanPath -Confirm:$false }
        if (-not (Test-StateActive "Default")) {
            Set-TimerState "Default"
            Request-Reboot "so your PC returns to the clean Windows default."
        }
        Write-Host " Done. Your system is at the Windows default and progress is cleared." -ForegroundColor Green
        Exit-Script 0
    }

    # ----- Load or create the plan -----
    if (Test-Path -LiteralPath $PlanPath) {
        $plan = Get-Content -LiteralPath $PlanPath -Raw | ConvertFrom-Json
        Write-Host (" Resuming saved test plan from {0}" -f $plan.createdLocal) -ForegroundColor Green
    } else {
        # Build the scenario list: baseline is ALWAYS step 1.
        $chosen = @()
        if ($Scenarios.Trim() -notin @("", "None", "none", "NONE")) {
            foreach ($s in ($Scenarios -split ",")) {
                $t = $s.Trim()
                if ($t -eq "") { continue }
                if ($AllScenarios -notcontains $t) { throw "Unknown scenario '$t'. Valid: $($AllScenarios -join ', ') (or None for baseline only)" }
                $chosen += $t
            }
        }
        $labelMap = @{
            "Default"="baseline_windows_default"; "PlatformClock"="useplatformclock_yes";
            "DynamicTick"="disabledynamictick_yes"; "PlatformTick"="useplatformtick_yes";
            "FullMyth"="full_myth_all_forced"
        }
        $states = @("Default") + $chosen
        $steps = @()
        for ($i = 0; $i -lt $states.Count; $i++) {
            $steps += [pscustomobject]@{
                State    = $states[$i]
                Label    = ("{0}_{1}" -f [char](65 + $i), $labelMap[$states[$i]])
                Measured = $false
                Csv      = ""
            }
        }
        $plan = [pscustomobject]@{
            createdLocal = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            steps        = $steps
            idx          = 0
            pendingState = ""
            applyTimeUtc = ""
        }

        Write-Host " New test plan created. Steps in order:" -ForegroundColor Green
        foreach ($s in $steps) { Write-Host ("   {0}  ({1})" -f $s.Label, $s.State) }
        Write-Host " Between steps the PC must restart; run this tool again after each restart."

        # BASELINE RULE: the baseline is whatever the user's Windows has NOW -
        # but only if that is the clean default. If any timer override is set,
        # the system is not original, so we apply the universal default first.
        $setNow = @(Get-SetTimerOptions)
        if ($setNow.Count -gt 0) {
            Write-Host ""
            Write-Host " Your Windows is NOT at the clean default right now:" -ForegroundColor Yellow
            foreach ($o in $setNow) { Write-Host ("   - {0} is set" -f $o) -ForegroundColor Yellow }
            Write-Host " To make the baseline trustworthy, the universal Windows default" -ForegroundColor Yellow
            Write-Host " will be applied first (a backup is taken automatically)." -ForegroundColor Yellow
            $ans = Read-Host " Type YES to continue"
            if ($ans -cne "YES") { Write-Host " Cancelled - nothing was changed." -ForegroundColor Yellow; Exit-Script 0 }
            Set-TimerState "Default"
            $plan.pendingState = "Default"
            $plan.applyTimeUtc = (Get-Date).ToUniversalTime().ToString("o")
            Save-Plan $plan
            Request-Reboot "so the clean baseline takes effect."
        } else {
            Write-Host ""
            Write-Host " Your Windows is already at the clean default - this IS the baseline." -ForegroundColor Green
            Save-Plan $plan
        }
    }

    # ----- If a state change is pending, make sure the PC restarted and the state is active -----
    if ($plan.pendingState) {
        $applied = [datetime]::Parse($plan.applyTimeUtc, [System.Globalization.CultureInfo]::InvariantCulture).ToUniversalTime()
        if ((Get-BootTimeUtc) -lt $applied) {
            Write-Host ""
            Write-Host " The PC has NOT restarted since the last settings change." -ForegroundColor Red
            Write-Host " BCD changes only take effect after a restart, so measuring now" -ForegroundColor Red
            Write-Host " would be meaningless." -ForegroundColor Red
            Request-Reboot "to activate the pending state '$($plan.pendingState)'."
        }
        if (-not (Test-StateActive $plan.pendingState)) {
            throw "After restart, the BCD does not match the expected state '$($plan.pendingState)'. Check with RUN-1_Show-Timer-Status.cmd, or use -Reset to start over."
        }
        Write-Host (" Restart confirmed - state '{0}' is active." -f $plan.pendingState) -ForegroundColor Green
        $plan.pendingState = ""
        $plan.applyTimeUtc = ""
        Save-Plan $plan
    }

    # ----- Measure the current step, then move to the next -----
    $steps = @($plan.steps)
    $step  = $steps[$plan.idx]

    Write-Host ""
    Write-Host (" STEP {0} of {1}: {2}" -f ($plan.idx + 1), $steps.Count, $step.Label) -ForegroundColor Cyan

    if (-not $step.Measured) {
        if (-not (Test-StateActive $step.State)) {
            throw "The current BCD state does not match this step ('$($step.State)'). Use -Reset to start over safely."
        }
        $step.Csv      = Invoke-Benchmark $step.Label
        $step.Measured = $true
        Save-Plan $plan
        Write-Host (" Step '{0}' measured and saved." -f $step.Label) -ForegroundColor Green
    }

    if (($plan.idx + 1) -lt $steps.Count) {
        # Apply the next scenario and ask for a restart.
        $next = $steps[$plan.idx + 1]
        Set-TimerState $next.State
        $plan.idx          = $plan.idx + 1
        $plan.pendingState = $next.State
        $plan.applyTimeUtc = (Get-Date).ToUniversalTime().ToString("o")
        Save-Plan $plan
        Request-Reboot ("to activate the next scenario: {0}." -f $next.Label)
    }

    # ----- All steps measured: restore the default and show the comparison -----
    Write-Host ""
    Write-Host " All scenarios are measured!" -ForegroundColor Green
    Show-FinalSummary $plan

    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    Move-Item -LiteralPath $PlanPath -Destination (Join-Path $PSScriptRoot ("TestPlan_completed_{0}.json" -f $stamp))

    if (-not (Test-StateActive "Default")) {
        Set-TimerState "Default"
        Write-Host ""
        Write-Host " TEST COMPLETE. The Windows default has been restored." -ForegroundColor Green
        Request-Reboot "one last time, so your PC returns to its normal (default) state."
    } else {
        Write-Host ""
        Write-Host " TEST COMPLETE. Your PC is already at the Windows default." -ForegroundColor Green
    }
    Exit-Script 0
}
catch {
    Write-Host ""
    Write-Host " ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host " Nothing else was changed. Your BCD backups are in the AlchemyHPET folder." -ForegroundColor Red
    Exit-Script 1
}
