<#
================================================================================
 Timer-Options-Menu.ps1   |   Alchemy Tweaks - HPET Debunk Package
================================================================================
 WHAT THIS IS
   An interactive menu to apply / revert EACH timer option individually, so
   you always know exactly WHAT changes, HOW it is changed (the exact
   bcdedit command), and WHY (official Microsoft documentation, quoted).

 COLOR LEGEND (used consistently everywhere)
   GREEN   = at the Windows DEFAULT (the baseline)      / success
   RED     = OVERRIDDEN (not the baseline)              / failure
   MAGENTA = restart reminders
   YELLOW  = questions and warnings
   GRAY    = commands and secondary details

 WHAT "DEFAULT / BASELINE" MEANS HERE (important!)
   DEFAULT = the option is NOT PRESENT in the boot configuration at all,
   and Windows auto-selects the best timer behavior. That is the baseline.
   - Revert always uses `bcdedit /deletevalue <option>`, which REMOVES the
     entry - the documented way back to default.
   - Setting an explicit value (even `useplatformclock no` or
     `tscsyncpolicy Default`) is STILL an override, not the default.

 SAFETY
   - A timestamped BCD backup (bcdedit /export) is taken automatically
     before EVERY change. Backups live in the AlchemyHPET folder.
   - Changes take effect only after a RESTART (full boot - use Restart,
     not Shut down, because of Windows Fast Startup).
   - Everything is fully reversible. This tool never restarts your PC.

 SOURCES (verified 2026-07-03)
   https://learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--set
   https://learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--deletevalue
   https://learn.microsoft.com/windows/win32/sysinfo/acquiring-high-resolution-time-stamps

 USAGE (easiest: double-click RUN-4_Timer-Options-Menu.cmd)
   powershell -ExecutionPolicy Bypass -File .\Timer-Options-Menu.ps1
================================================================================
#>

[CmdletBinding()]
param(
    [switch] $NoPause,

    # Internal marker: set automatically when the script relaunches itself
    # elevated. Do not pass it yourself.
    [Parameter(DontShow)]
    [switch] $Elevated
)

$ErrorActionPreference = "Stop"

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Exit-Script([int]$code) {
    if (-not $NoPause) {
        Write-Host ""
        Read-Host " Press Enter to close this window" | Out-Null
    }
    exit $code
}

# ---------------------------------------------------------------------------
# Self-elevation
# ---------------------------------------------------------------------------
if (-not (Test-Admin)) {
    Write-Host ""
    Write-Host " This tool needs Administrator rights (bcdedit requires them)." -ForegroundColor Yellow
    Write-Host " Requesting elevation - please approve the UAC prompt..." -ForegroundColor Yellow
    $psExe = if ($PSVersionTable.PSEdition -eq "Core") { "pwsh.exe" } else { "powershell.exe" }
    $argList = @("-NoProfile","-ExecutionPolicy","Bypass","-File", ('"{0}"' -f $PSCommandPath))
    foreach ($kv in $PSBoundParameters.GetEnumerator()) {
        if ($kv.Value -is [System.Management.Automation.SwitchParameter]) {
            if ($kv.Value) { $argList += ("-{0}" -f $kv.Key) }
        } else {
            $argList += ("-{0}" -f $kv.Key)
            $argList += ('"{0}"' -f $kv.Value)
        }
    }
    $argList += "-Elevated"
    try {
        Start-Process -FilePath $psExe -Verb RunAs -ArgumentList ($argList -join " ") | Out-Null
        Write-Host " Elevated window launched. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        Write-Host " Elevation was declined or failed. Nothing was changed." -ForegroundColor Red
        Exit-Script 1
    }
}

Set-Location -LiteralPath $PSScriptRoot
$BackupDir = Join-Path $PSScriptRoot "AlchemyHPET"

# ---------------------------------------------------------------------------
# The option catalog. Official* fields are quoted verbatim from Microsoft
# Learn (BCDEdit /set). Plain / Role are our explanations, clearly separated.
# ---------------------------------------------------------------------------
$Catalog = [ordered]@{
    "useplatformclock" = [pscustomobject]@{
        Values       = "yes | no"
        ApplyArgs    = @("/set","useplatformclock","yes")
        ApplyShown   = "bcdedit /set useplatformclock yes"
        OfficialDesc = '"Forces the use of the platform clock as the system''s performance counter."'
        OfficialNote = '"This option should only be used for debugging."'
        Plain        = "With 'yes', the high-precision counter (QPC) stops using the fast per-core TSC path and is served by a platform timer (HPET or ACPI PM timer). Microsoft's QPC FAQ: platform-timer reads need a kernel transition and typically cost about 0.8-1.0 microseconds per call, versus tens or hundreds of CPU cycles for the TSC."
        Role         = "This is THE core 'enable HPET' myth tweak. The package measures what it really does to timer read cost."
    }
    "useplatformtick" = [pscustomobject]@{
        Values       = "yes | no"
        ApplyArgs    = @("/set","useplatformtick","yes")
        ApplyShown   = "bcdedit /set useplatformtick yes"
        OfficialDesc = '"Forces the clock to be backed by a platform source, no synthetic timers are allowed." (Windows 8 and later)'
        OfficialNote = '"This option should only be used for debugging."'
        Plain        = "With 'yes', the system clock/tick must come from a platform hardware source; synthetic (software or hypervisor) timers are not allowed."
        Role         = "Often bundled with the HPET myth as a 'timer resolution' tweak. Tested as a separate scenario."
    }
    "disabledynamictick" = [pscustomobject]@{
        Values       = "yes | no"
        ApplyArgs    = @("/set","disabledynamictick","yes")
        ApplyShown   = "bcdedit /set disabledynamictick yes"
        OfficialDesc = '"Enables and disables dynamic timer tick feature."'
        OfficialNote = '"This option should only be used for debugging."'
        Plain        = "With 'yes', the 'dynamic tick' feature is turned OFF, so the kernel keeps a fixed periodic timer tick instead of managing it dynamically (dynamic tick is a power-saving behavior introduced in Windows 8)."
        Role         = "The 'disable dynamic tick for smoothness' myth. Tested as a separate scenario."
    }
    "tscsyncpolicy" = [pscustomobject]@{
        Values       = "Default | Legacy | Enhanced"
        ApplyArgs    = $null    # value chosen interactively
        ApplyShown   = "bcdedit /set tscsyncpolicy <Default|Legacy|Enhanced>"
        OfficialDesc = '"Controls the times stamp counter synchronization policy."'
        OfficialNote = '"This option should only be used for debugging."'
        Plain        = "Selects which TSC synchronization algorithm the kernel uses. Note: even setting the value 'Default' is still an explicit override in the boot store - only /deletevalue returns to the true Windows default."
        Role         = "Included for completeness: it appears in many 'timer tweak' guides. It governs boot-time TSC synchronisation only, never the per-read path. IMPORTANT: on current Windows 11 builds this option is inert. Decompilation of the Windows boot-option parser shows the code that reads TSCSYNCPOLICY present in older builds and absent in the current one, the kernel symbol no longer resolves, and measured timer read cost is identical across Default, Legacy and Enhanced. bcdedit still writes the value and shows it, but nothing acts on it. On older builds /deletevalue and Default are the same value, legacy=1, enhanced=2."
    }
}
$OptionNames = @($Catalog.Keys)

# ---------------------------------------------------------------------------
# bcdedit helpers (safe against the PS 5.1 stderr/Stop interaction)
# ---------------------------------------------------------------------------
function Invoke-Bcdedit([string[]]$BcdArgs) {
    $eap = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $out  = & bcdedit @BcdArgs 2>&1
        $code = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $eap
    }
    $text = @($out | ForEach-Object { "$_" }) -join [Environment]::NewLine
    return [pscustomobject]@{ ExitCode = $code; Output = $text }
}

function Get-CurrentValues {
    $res = Invoke-Bcdedit @("/enum","{current}")
    if ($res.ExitCode -ne 0) { throw "bcdedit /enum failed: $($res.Output)" }
    $lines = $res.Output -split "\r?\n"
    $map = @{}
    foreach ($opt in $OptionNames) {
        $line = $lines | Where-Object { $_ -match ("^\s*{0}\s+\S" -f [regex]::Escape($opt)) } | Select-Object -First 1
        if ($line) { $map[$opt] = ($line -replace ("^\s*{0}\s+" -f [regex]::Escape($opt)), "").Trim() }
        else       { $map[$opt] = $null }
    }
    return $map
}

function New-BcdBackup {
    if (-not (Test-Path -LiteralPath $BackupDir)) { New-Item -ItemType Directory -Path $BackupDir | Out-Null }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
    $bak   = Join-Path $BackupDir ("bcd-backup-{0}.bcd" -f $stamp)
    $res = Invoke-Bcdedit @("/export", $bak)
    if ($res.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $bak)) {
        throw "BCD backup FAILED ($($res.Output)). Aborting - no changes were made."
    }
    Write-Host  ("   Backup saved : {0}" -f (Split-Path $bak -Leaf)) -ForegroundColor Green
    Write-Host  ("   Restore with : bcdedit /import `"{0}`"" -f $bak) -ForegroundColor DarkGray
    return $bak
}

# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------
$W = 64                                    # layout width for rules and wrapping

function Clear-View { try { Clear-Host } catch { } }

function Write-Rule([string]$char = "-") { Write-Host ("  " + ($char * $W)) -ForegroundColor DarkCyan }

function Write-Title([string]$text) {
    Write-Host ""
    Write-Rule "="
    Write-Host ("  {0}" -f $text) -ForegroundColor Cyan
    Write-Rule "="
}

function Write-Section([string]$text) {
    Write-Host ""
    Write-Host ("  {0}" -f $text) -ForegroundColor Cyan
    Write-Rule
}

# Word-wraps text at a fixed width with a hanging indent - the key to
# keeping long documentation paragraphs readable in a console.
function Write-Wrapped([string]$text, [ConsoleColor]$color = [ConsoleColor]::Gray, [string]$indent = "    ") {
    $limit = $W - $indent.Length
    $line  = ""
    foreach ($word in ($text -split "\s+")) {
        if ($line -and (($line.Length + 1 + $word.Length) -gt $limit)) {
            Write-Host ($indent + $line) -ForegroundColor $color
            $line = $word
        } else {
            $line = if ($line) { "$line $word" } else { $word }
        }
    }
    if ($line) { Write-Host ($indent + $line) -ForegroundColor $color }
}

function Write-StateLine([int]$num, [string]$opt, $value) {
    Write-Host ("   [{0}]  {1,-20} " -f $num, $opt) -NoNewline
    if ([string]::IsNullOrEmpty($value)) { Write-Host "DEFAULT" -ForegroundColor Green }
    else                                 { Write-Host ("OVERRIDDEN  ({0})" -f $value) -ForegroundColor Red }
}

function Read-Choice([string]$prompt = "Your choice") {
    Write-Host ""
    return (Read-Host ("  {0}" -f $prompt)).Trim().ToUpper()
}

function Wait-Return {
    Write-Host ""
    Read-Host "  Press Enter to return to the menu" | Out-Null
}

$script:ChangesMade = $false

# ---------------------------------------------------------------------------
# Views
# ---------------------------------------------------------------------------
function Show-MainMenu {
    Clear-View
    Write-Title "ALCHEMY TWEAKS  -  TIMER OPTIONS  (manual apply / revert)"

    Write-Section "CURRENT STATE          (baseline = every option DEFAULT)"
    $cur = Get-CurrentValues
    $i = 0
    foreach ($opt in $OptionNames) { $i++; Write-StateLine $i $opt $cur[$opt] }
    Write-Rule

    $overridden = @($OptionNames | Where-Object { $null -ne $cur[$_] })
    Write-Host "   Baseline check  : " -NoNewline
    if ($overridden.Count -eq 0) {
        Write-Host "OK - system is at the clean Windows default" -ForegroundColor Green
    } else {
        Write-Host ("NOT at baseline - {0} option(s) overridden" -f $overridden.Count) -ForegroundColor Red
    }
    Write-Host "   Restart needed  : " -NoNewline
    if ($script:ChangesMade) {
        Write-Host "YES - changes made this session; RESTART to apply" -ForegroundColor Magenta
    } else {
        Write-Host "no changes made in this session yet" -ForegroundColor DarkGray
    }

    Write-Section "WHAT YOU CAN DO"
    Write-Host "   1-4    Inspect one option (full info), then apply or revert it"
    Write-Host "   A      Apply ALL yes/no overrides at once   " -NoNewline
    Write-Host "(the 'full myth')" -ForegroundColor DarkGray
    Write-Host "   R      Revert ALL to the Windows default    " -NoNewline
    Write-Host "(the baseline)" -ForegroundColor DarkGray
    Write-Host "   Q      Quit"
    Write-Host ""
    Write-Host "   Every change: automatic backup, fully reversible, active" -ForegroundColor DarkGray
    Write-Host "   only after a RESTART (use Restart, not Shut down)." -ForegroundColor DarkGray
}

function Show-OptionDetail([string]$opt, [int]$num) {
    $info = $Catalog[$opt]
    $cur  = (Get-CurrentValues)[$opt]

    Clear-View
    Write-Title ("OPTION {0} of 4  :  {1}" -f $num, $opt)

    Write-Host ""
    Write-Host "   Current value    " -NoNewline
    if ($null -eq $cur) { Write-Host "DEFAULT (not present - Windows auto-selects)" -ForegroundColor Green }
    else                { Write-Host ("OVERRIDDEN  ({0})" -f $cur) -ForegroundColor Red }
    Write-Host ("   Possible values  {0}" -f $info.Values)

    Write-Section "WHAT MICROSOFT SAYS   (BCDEdit /set, verified 2026-07-03)"
    Write-Wrapped $info.OfficialDesc ([ConsoleColor]::White)
    Write-Wrapped $info.OfficialNote ([ConsoleColor]::Yellow)

    Write-Section "WHAT THAT MEANS IN PLAIN WORDS"
    Write-Wrapped $info.Plain ([ConsoleColor]::Gray)

    Write-Section "WHY IT IS IN THIS PACKAGE"
    Write-Wrapped $info.Role ([ConsoleColor]::Gray)

    Write-Section "EXACT COMMANDS THIS TOOL RUNS"
    Write-Host ("    Apply   : {0}" -f $info.ApplyShown) -ForegroundColor White
    Write-Host ("    Revert  : bcdedit /deletevalue {0}" -f $opt) -ForegroundColor White
    Write-Host  "              (removes the entry = back to the true default)" -ForegroundColor DarkGray

    Write-Section "ACTIONS"
    Write-Host "   A      Apply the override"
    Write-Host "   R      Revert to the Windows default"
    Write-Host "   B      Back to the menu"
}

function Confirm-Change([string]$commandShown) {
    Write-Host ""
    Write-Rule
    Write-Host  "   You are about to run:" -ForegroundColor Yellow
    Write-Host ("     {0}" -f $commandShown) -ForegroundColor White
    Write-Host  "   It changes the boot configuration and becomes active only" -ForegroundColor Yellow
    Write-Host  "   after a RESTART. A backup is taken first automatically." -ForegroundColor Yellow
    $ans = Read-Host "   Type YES to continue, anything else to cancel"
    return ($ans.Trim() -ceq "YES")
}

function Invoke-Change([string[]]$bcdArgs, [string]$okMessage) {
    Write-Host ""
    New-BcdBackup | Out-Null
    Write-Host ("   Running      : bcdedit {0}" -f ($bcdArgs -join " ")) -ForegroundColor White
    $res = Invoke-Bcdedit $bcdArgs
    if ($res.ExitCode -ne 0) {
        if ($bcdArgs[0] -eq "/deletevalue") {
            Write-Host "   Result       : option was not set - already at default" -ForegroundColor Green
            return
        }
        Write-Host ("   Result       : FAILED - {0}" -f $res.Output) -ForegroundColor Red
        return
    }
    $script:ChangesMade = $true
    Write-Host ("   Result       : OK - {0}" -f $okMessage) -ForegroundColor Green
    Write-Host  "   Reminder     : RESTART required before this takes effect" -ForegroundColor Magenta
}

function Invoke-OptionMenu([string]$opt, [int]$num) {
    Show-OptionDetail $opt $num
    $choice = Read-Choice "Your choice (A / R / B)"
    switch ($choice) {
        "A" {
            if ($opt -eq "tscsyncpolicy") {
                $val = (Read-Host "  Which value? (Default / Legacy / Enhanced)").Trim()
                if ($val -notin @("Default","Legacy","Enhanced")) {
                    Write-Host "  Invalid value - nothing was changed." -ForegroundColor Yellow
                    Wait-Return; return
                }
                if (Confirm-Change ("bcdedit /set tscsyncpolicy {0}" -f $val)) {
                    Invoke-Change @("/set","tscsyncpolicy",$val) ("tscsyncpolicy override set to {0}" -f $val)
                } else { Write-Host "  Cancelled - nothing was changed." -ForegroundColor Yellow }
            } else {
                $info = $Catalog[$opt]
                if (Confirm-Change $info.ApplyShown) {
                    Invoke-Change $info.ApplyArgs ("{0} override set to yes" -f $opt)
                } else { Write-Host "  Cancelled - nothing was changed." -ForegroundColor Yellow }
            }
            Wait-Return
        }
        "R" {
            if (Confirm-Change ("bcdedit /deletevalue {0}" -f $opt)) {
                Invoke-Change @("/deletevalue",$opt) ("{0} removed - back to the Windows default" -f $opt)
            } else { Write-Host "  Cancelled - nothing was changed." -ForegroundColor Yellow }
            Wait-Return
        }
        default { }
    }
}

# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------
try {
    while ($true) {
        Show-MainMenu
        $choice = Read-Choice "Your choice (1-4 / A / R / Q)"

        switch ($choice) {
            "1" { Invoke-OptionMenu $OptionNames[0] 1 }
            "2" { Invoke-OptionMenu $OptionNames[1] 2 }
            "3" { Invoke-OptionMenu $OptionNames[2] 3 }
            "4" { Invoke-OptionMenu $OptionNames[3] 4 }
            "A" {
                if (Confirm-Change "bcdedit /set useplatformclock yes  +  useplatformtick yes  +  disabledynamictick yes") {
                    Write-Host ""
                    New-BcdBackup | Out-Null
                    foreach ($opt in @("useplatformclock","useplatformtick","disabledynamictick")) {
                        Write-Host ("   Running      : bcdedit /set {0} yes" -f $opt) -ForegroundColor White
                        $res = Invoke-Bcdedit @("/set",$opt,"yes")
                        if ($res.ExitCode -ne 0) { Write-Host ("   Result       : FAILED - {0}" -f $res.Output) -ForegroundColor Red }
                        else { $script:ChangesMade = $true; Write-Host "   Result       : OK" -ForegroundColor Green }
                    }
                    Write-Host "   Reminder     : RESTART required before these take effect" -ForegroundColor Magenta
                } else { Write-Host "  Cancelled - nothing was changed." -ForegroundColor Yellow }
                Wait-Return
            }
            "R" {
                if (Confirm-Change "bcdedit /deletevalue for all four timer options (back to the baseline)") {
                    Write-Host ""
                    New-BcdBackup | Out-Null
                    foreach ($opt in $OptionNames) {
                        Write-Host ("   Running      : bcdedit /deletevalue {0}" -f $opt) -ForegroundColor White
                        $res = Invoke-Bcdedit @("/deletevalue",$opt)
                        if ($res.ExitCode -ne 0) { Write-Host "   Result       : was not set - already at default" -ForegroundColor Green }
                        else { $script:ChangesMade = $true; Write-Host "   Result       : OK - removed" -ForegroundColor Green }
                    }
                    Write-Host "   The boot store is back at the Windows DEFAULT (baseline)." -ForegroundColor Green
                    Write-Host "   Reminder     : RESTART required before this takes effect" -ForegroundColor Magenta
                } else { Write-Host "  Cancelled - nothing was changed." -ForegroundColor Yellow }
                Wait-Return
            }
            "Q" {
                if ($script:ChangesMade) {
                    Write-Host ""
                    Write-Host "  You made changes: RESTART your PC for them to take effect." -ForegroundColor Magenta
                    Write-Host "  Use RESTART, not Shut down (Fast Startup skips a full boot)." -ForegroundColor Magenta
                    Write-Host "  Verify afterwards with RUN-1_Show-Timer-Status.cmd." -ForegroundColor Magenta
                }
                Exit-Script 0
            }
            default { }
        }
    }
}
catch {
    Write-Host ""
    Write-Host " ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host " Your BCD backups are in the AlchemyHPET folder." -ForegroundColor Red
    Exit-Script 1
}
