=============================================================================
 ALCHEMY HPET PACKAGE - HOW TO USE (2 minutes read)
=============================================================================

 WHAT THIS PACKAGE DOES
   It measures, on YOUR machine, what the famous "HPET / useplatformclock"
   tweaks really do to the Windows high-precision timer (QPC). No guessing,
   no myths - just measurements you can repeat yourself.

 THE FOUR BUTTONS (double-click, approve the admin prompt)

   RUN-1_Show-Timer-Status.cmd
       Shows your current timer settings. 100% read-only and safe.

   RUN-2_Measure-Timer-Speed.cmd
       Measures the cost of reading the timer (nanoseconds per call).
       100% read-only and safe. Results are saved as CSV in "qpc_results".

   RUN-3_Complete-Auto-Test.cmd
       The full guided experiment. It will:
         1. Make sure the test starts from the clean Windows default
            (your real baseline).
         2. Measure the baseline.
         3. Apply each test scenario, ask you to restart, verify it,
            and measure it.
         4. Restore the clean Windows default and show a comparison table.
       IMPORTANT: after every restart, run RUN-3 again. It remembers where
       it stopped and continues, until it says TEST COMPLETE.

   RUN-4_Timer-Options-Menu.cmd
       For full manual control: an interactive menu that shows each of the
       four timer options with the official Microsoft description, the
       exact command used, and whether it is at the DEFAULT (baseline) or
       OVERRIDDEN - and lets you apply or revert each one individually
       (or everything at once). Every change is backed up first.

 ONE IMPORTANT RULE ABOUT RESTARTS
   Timer (BCD) changes take effect ONLY after a full boot. Always use
   RESTART from the Start menu. Do NOT use "Shut down" + power on: with
   Windows Fast Startup (on by default) that is NOT a full boot, and the
   change will not be applied. (Restart always performs a full boot.)

 IS THIS SAFE?
   - Every boot-setting change is backed up automatically first
     (folder "AlchemyHPET"). Everything is fully reversible.
   - Nothing restarts your PC without asking you.
   - If BitLocker is enabled, suspend it first (the tools warn you).

 FOR ADVANCED USERS
   The buttons run these PowerShell scripts, which contain full
   documentation and sources (Microsoft Learn) in their headers:
     Change-Timer-Settings.ps1   - show / apply / revert timer states
     Measure-Timer-Speed.ps1     - the QPC read-cost benchmark
     Run-Complete-Test.ps1       - the guided test runner
     Timer-Options-Menu.ps1      - per-option apply/revert with docs

 A NOTE ON tscsyncpolicy  (IMPORTANT - it is inert on current Windows 11)
   Microsoft documents this as a debugging-only setting that affects how
   the CPU clock is synchronized AT BOOT, never per frame.

   On current Windows 11 builds it does nothing at all. Decompilation of
   the Windows boot-option parser shows the code that reads TSCSYNCPOLICY
   present in older builds and absent in the current one, the kernel
   symbol no longer resolves, and the measured timer read cost is
   identical across Default, Legacy and Enhanced. bcdedit still writes the
   value and bcdedit /enum still shows it, but nothing consumes it.

   Practical consequence: any FPS difference you measure between these
   states is session-to-session variation, not the setting. On older
   builds where it did work, "Default" and /deletevalue were the same
   value. Microsoft documents neither the removal nor the behaviour, so
   record your build number if you cite this.

=============================================================================
