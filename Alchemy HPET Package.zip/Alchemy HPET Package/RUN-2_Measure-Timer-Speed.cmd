@echo off
rem =========================================================================
rem  Alchemy HPET Package - launcher 2 of 3
rem  MEASURES how expensive it is to read the timer right now. Read-only.
rem  Tip: pass a label so your CSV files are self-describing, e.g.:
rem    RUN-2_Measure-Timer-Speed.cmd -Label A_default
rem =========================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Measure-Timer-Speed.ps1" %*
