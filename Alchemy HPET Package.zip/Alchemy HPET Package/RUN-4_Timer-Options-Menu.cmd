@echo off
rem =========================================================================
rem  Alchemy HPET Package - launcher 4 of 4
rem  INTERACTIVE MENU: apply / revert each timer option one by one, with
rem  the official Microsoft documentation shown for every option, the
rem  exact command used, and a clear DEFAULT/OVERRIDDEN state display.
rem  Every change is backed up automatically and is fully reversible.
rem =========================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Timer-Options-Menu.ps1" %*
