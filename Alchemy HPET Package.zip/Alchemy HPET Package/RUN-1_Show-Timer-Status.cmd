@echo off
rem =========================================================================
rem  Alchemy HPET Package - launcher 1 of 3
rem  SHOWS the current timer state. Read-only, changes nothing.
rem =========================================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Change-Timer-Settings.ps1" -Action Status %*
