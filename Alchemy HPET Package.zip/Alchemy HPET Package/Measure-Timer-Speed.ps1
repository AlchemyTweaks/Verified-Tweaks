<#
================================================================================
 Measure-Timer-Speed.ps1   |   Alchemy Tweaks - HPET Debunk Package
================================================================================
 PURPOSE
   The decisive measurement for the HPET / useplatformclock test matrix.
   Directly measures the COST of reading the QueryPerformanceCounter (QPC)
   timer on THIS system: nanoseconds per call and calls per second,
   single-threaded AND multi-threaded.

   It isolates the timer-read path (the exact thing useplatformclock changes)
   BEFORE any FPS chart. Run it once per BCD state (A = default, B = forced
   platform clock, ...) and compare the numbers. The DELTA is the evidence.

 WHAT THE NUMBERS MEAN (verified against Microsoft Learn, 2026-07-03)
   - TSC-backed QPC: read cost is "in the order of 10s or 100s of machine
     cycles" (roughly a few ns to a few tens of ns) and needs NO kernel
     transition.
   - Platform-timer QPC (HPET / ACPI PM timer): Microsoft documents the
     per-call cost as "frequently in the vicinity of 0.8 - 1.0 microseconds"
     and states that a system call (kernel transition) IS required.
   - HPET is "a shared, platform-wide resource" (unlike the per-processor
     TSC), and platform timers "limit scalability of QPC if it is called
     concurrently from multiple processors". So under a forced platform
     clock, TOTAL multi-thread throughput stops improving (or drops below
     the single-thread rate); on the TSC path it keeps increasing.
     NOTE: even on a healthy TSC system total throughput does NOT grow
     perfectly linearly with thread count (power management, SMT and cache
     effects) - which is why this tool reports a concurrency GAIN ratio and
     not a misleading "percent of ideal N x" figure.
   Sources:
     https://learn.microsoft.com/windows/win32/sysinfo/acquiring-high-resolution-time-stamps
     (sections: "QPC support in Windows versions", "General FAQ about QPC and
      TSC" - computational cost, kernel transition - and "Hardware timer info")

 SAFETY
   - 100% READ-ONLY measurement. Makes NO changes to BCD, registry, drivers
     or firmware. Administrator rights are NOT scientifically required; the
     script still self-elevates by default so it always runs the same way,
     with full privileges and High process priority for stable numbers.
     Use -NoElevate to skip the UAC prompt.

 USAGE (easiest: double-click the matching .cmd launcher in this folder)
   powershell -ExecutionPolicy Bypass -File .\Measure-Timer-Speed.ps1
   powershell -ExecutionPolicy Bypass -File .\Measure-Timer-Speed.ps1 -Label "B_useplatformclock_yes"

 PARAMETERS
   -Iterations   QPC calls per single-thread run. Default: auto-calibrated so
                 each run lasts ~1.5 s in ANY state (fast even when the slow
                 platform timer is forced). Pass a fixed value to override.
   -Threads      threads for the multi-thread test (default: logical CPUs)
   -Repetitions  runs per test                     (default 5)
   -Label        state label written into the CSV (e.g. A_default / B_hpet)
   -OutDir       output folder for the CSV        (default <script>\qpc_results)
   -NoElevate    run without asking for Administrator elevation
   -NoPause      do not wait for Enter before the window closes

 OUTPUT
   - Console table with median / mean / min / max / stddev / CoV.
   - CSV appended per run: <OutDir>\qpc_<Label>_<timestamp>.csv
   - The multi-thread test issues the SAME TOTAL number of calls, split
     evenly across threads, so its duration stays comparable.
================================================================================
#>

[CmdletBinding()]
param(
    [ValidateRange(100000, 2000000000)]
    [long]   $Iterations  = 0,          # 0 = auto-calibrate (~1.5 s per run)

    [ValidateRange(1, 256)]
    [int]    $Threads     = [Environment]::ProcessorCount,

    [ValidateRange(1, 50)]
    [int]    $Repetitions = 5,

    [string] $Label       = "unlabeled",
    [string] $OutDir      = "",
    [switch] $NoElevate,
    [switch] $NoPause,

    # Internal marker: set automatically when the script relaunches itself
    # elevated. Do not pass it yourself.
    [Parameter(DontShow)]
    [switch] $Elevated
)

$ErrorActionPreference = "Stop"
# Force dot-decimal number formatting so the CSV stays valid on every locale.
[System.Threading.Thread]::CurrentThread.CurrentCulture = [System.Globalization.CultureInfo]::InvariantCulture

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Exit-Script([int]$code) {
    if (-not $NoPause) {
        Write-Host ""
        Read-Host " Press Enter to close this window" | Out-Null
    }
    exit $code
}

# ---------------------------------------------------------------------------
# Self-elevation (optional for a read-only benchmark, on by default so the
# tool always runs identically, with full privileges).
# ---------------------------------------------------------------------------
if (-not $NoElevate -and -not (Test-Admin)) {
    Write-Host ""
    Write-Host " Requesting elevation for a consistent, high-priority run..." -ForegroundColor Yellow
    Write-Host " (The benchmark itself is read-only; use -NoElevate to skip this.)" -ForegroundColor Yellow

    $psExe = if ($PSVersionTable.PSEdition -eq "Core") { "pwsh.exe" } else { "powershell.exe" }
    $argList = @("-NoProfile","-ExecutionPolicy","Bypass","-File", ('"{0}"' -f $PSCommandPath))
    foreach ($kv in $PSBoundParameters.GetEnumerator()) {
        if ($kv.Value -is [System.Management.Automation.SwitchParameter]) {
            if ($kv.Value) { $argList += ("-{0}" -f $kv.Key) }
        } else {
            $argList += ("-{0}" -f $kv.Key)
            $argList += ('"{0}"' -f $kv.Value)
        }
    }
    $argList += "-Elevated"

    try {
        Start-Process -FilePath $psExe -Verb RunAs -ArgumentList ($argList -join " ") | Out-Null
        Write-Host " Elevated window launched. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        Write-Host " Elevation declined - continuing WITHOUT elevation (results are still valid)." -ForegroundColor DarkYellow
    }
}

Set-Location -LiteralPath $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($OutDir)) { $OutDir = Join-Path $PSScriptRoot "qpc_results" }

# ---------------------------------------------------------------------------
# Inline C# benchmark core (compiled -> accurate; PowerShell loops are far
# too slow and would measure the interpreter, not the timer).
# The timed loop contains only: one QPC call + one add (loop overhead is
# ~1 ns and identical in every state, so it cancels out in A/B comparison).
# ---------------------------------------------------------------------------
$cs = @"
using System;
using System.Runtime.InteropServices;
using System.Threading;

public static class QpcBench
{
    [DllImport("kernel32.dll")] public static extern bool QueryPerformanceCounter(out long c);
    [DllImport("kernel32.dll")] public static extern bool QueryPerformanceFrequency(out long f);

    public static long Freq() { long f; QueryPerformanceFrequency(out f); return f; }

    // Single-thread latency: returns nanoseconds per QPC call.
    public static double BenchSingleNs(long iters)
    {
        long freq; QueryPerformanceFrequency(out freq);
        long start, end, sink = 0, v;
        for (long i = 0; i < 100000; i++) { QueryPerformanceCounter(out v); sink += v; }   // warm-up
        QueryPerformanceCounter(out start);
        for (long i = 0; i < iters; i++) { QueryPerformanceCounter(out v); sink += v; }
        QueryPerformanceCounter(out end);
        GC.KeepAlive(sink);
        double seconds = (double)(end - start) / (double)freq;
        return seconds * 1e9 / (double)iters;
    }

    // Multi-thread aggregate throughput: TOTAL calls per second across all
    // threads. A per-core source (TSC) keeps gaining with more threads; a
    // shared platform timer (HPET/PM) serializes and stops gaining.
    public static double BenchMultiCallsPerSec(long itersPerThread, int threads)
    {
        long freq; QueryPerformanceFrequency(out freq);
        Thread[] ts = new Thread[threads];
        for (int t = 0; t < threads; t++)
        {
            ts[t] = new Thread(delegate()
            {
                long sink = 0, v;
                for (long i = 0; i < itersPerThread; i++) { QueryPerformanceCounter(out v); sink += v; }
                GC.KeepAlive(sink);
            });
            ts[t].IsBackground = true;
        }
        long start, end;
        QueryPerformanceCounter(out start);
        for (int t = 0; t < threads; t++) ts[t].Start();
        for (int t = 0; t < threads; t++) ts[t].Join();
        QueryPerformanceCounter(out end);
        double seconds = (double)(end - start) / (double)freq;
        double totalCalls = (double)itersPerThread * (double)threads;
        return totalCalls / seconds;
    }
}
"@

if (-not ("QpcBench" -as [type])) {
    try {
        Add-Type -TypeDefinition $cs -Language CSharp
    } catch {
        Write-Host " ERROR: could not compile the benchmark core. $_" -ForegroundColor Red
        Exit-Script 1
    }
}

function Get-QpfReading([long]$freq) {
    # QPF is an INDICATOR only. Microsoft: under a hypervisor v1.0 interface,
    # or always in some newer versions of Windows, QPF is fixed to 10 MHz
    # regardless of the hardware source. The read cost below is the proof.
    switch ($freq) {
        10000000 { return "10.000 MHz -> standard fixed value on modern Windows. Indicator only, NOT proof of the source." }
        3579545  { return "3.579545 MHz -> ACPI PM timer (platform timer)." }
        14318180 { return "14.318 MHz -> HPET (platform timer)." }
        default {
            if ($freq -ge 1000000000) { return "$([math]::Round($freq/1e6,3)) MHz -> raw TSC frequency (older QPC behavior)." }
            elseif ($freq -ge 12000000 -and $freq -le 30000000) { return "$([math]::Round($freq/1e6,3)) MHz -> HPET-class platform timer (frequency varies by chipset)." }
            else { return "$([math]::Round($freq/1e6,6)) MHz -> non-standard; judge by the read cost below." }
        }
    }
}

function Get-Stats([double[]]$vals) {
    $sorted = @($vals | Sort-Object)
    $n = $sorted.Count
    $mean = ($sorted | Measure-Object -Average).Average
    if ($n % 2 -eq 1) { $median = $sorted[[int][math]::Floor($n/2)] }
    else              { $median = ($sorted[[int]($n/2) - 1] + $sorted[[int]($n/2)]) / 2 }
    $min = $sorted[0]; $max = $sorted[$n-1]
    if ($n -gt 1) {
        $var = 0.0; foreach ($x in $sorted) { $var += [math]::Pow($x - $mean, 2) }
        $sd = [math]::Sqrt($var / ($n - 1))
    } else { $sd = 0.0 }
    $cov = if ($mean -ne 0) { 100.0 * $sd / $mean } else { 0.0 }
    return [pscustomobject]@{ Median=$median; Mean=$mean; Min=$min; Max=$max; StdDev=$sd; CoV=$cov }
}

function ConvertTo-CsvSafe([string]$s) { return ($s -replace ",", ";").Trim() }

# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
try {
    if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $csv   = Join-Path $OutDir ("qpc_{0}_{1}.csv" -f $Label, $stamp)

    # Raise process priority for stable numbers; restored automatically on exit.
    $proc = [System.Diagnostics.Process]::GetCurrentProcess()
    $oldPriority = $proc.PriorityClass
    try { $proc.PriorityClass = [System.Diagnostics.ProcessPriorityClass]::High } catch { }

    $freq = [QpcBench]::Freq()

    # Auto-calibration: probe the current per-call cost, then size the run so
    # every state (fast TSC or slow forced HPET) takes ~1.5 s per repetition.
    $calibrated = $false
    if ($Iterations -le 0) {
        $probeNs    = [QpcBench]::BenchSingleNs(200000)
        $Iterations = [long][math]::Max(1000000, [math]::Min(100000000, 1.5e9 / $probeNs))
        $calibrated = $true
    }
    $perThread = [long][math]::Max(100000, [math]::Floor($Iterations / $Threads))

    $cpuName = ""
    $osName  = ""
    try { $cpuName = (Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1).Name } catch { }
    try { $osName  = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption + " " + [Environment]::OSVersion.Version } catch { }

    Write-Host ""
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host " Alchemy - QPC Read-Cost Benchmark" -ForegroundColor Cyan
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host (" State label     : {0}" -f $Label)
    Write-Host (" Timestamp       : {0}" -f (Get-Date))
    if ($cpuName) { Write-Host (" CPU             : {0}" -f $cpuName.Trim()) }
    if ($osName)  { Write-Host (" OS              : {0}" -f $osName) }
    Write-Host (" Elevated        : {0}   Priority: {1}" -f (Test-Admin), $proc.PriorityClass)
    Write-Host (" Logical CPUs    : {0}   Threads used: {1}" -f [Environment]::ProcessorCount, $Threads)
    Write-Host (" Iterations/run  : {0:N0} (single)   {1:N0} (per thread, multi){2}" -f $Iterations, $perThread, $(if ($calibrated) {"   [auto-calibrated ~1.5 s/run]"} else {""}))
    Write-Host (" Repetitions     : {0}" -f $Repetitions)
    Write-Host ""
    Write-Host (" QueryPerformanceFrequency : {0:N0} Hz" -f $freq) -ForegroundColor Yellow
    Write-Host ("   -> {0}" -f (Get-QpfReading $freq)) -ForegroundColor Yellow
    Write-Host ""

    # CSV header + metadata rows
    "run,label,qpf_hz,metric,value,unit" | Out-File -FilePath $csv -Encoding utf8
    "meta,{0},{1},cpu,{2},text"        -f $Label, $freq, (ConvertTo-CsvSafe $cpuName) | Out-File -FilePath $csv -Append -Encoding utf8
    "meta,{0},{1},os,{2},text"         -f $Label, $freq, (ConvertTo-CsvSafe $osName)  | Out-File -FilePath $csv -Append -Encoding utf8
    "meta,{0},{1},threads,{2},count"   -f $Label, $freq, $Threads                     | Out-File -FilePath $csv -Append -Encoding utf8
    "meta,{0},{1},iterations,{2},count" -f $Label, $freq, $Iterations                 | Out-File -FilePath $csv -Append -Encoding utf8

    # ---- Single-thread latency (ns/call) ----
    Write-Host " Single-thread QPC latency (ns/call):" -ForegroundColor Green
    $single = @()
    for ($r = 1; $r -le $Repetitions; $r++) {
        $ns = [QpcBench]::BenchSingleNs($Iterations)
        $single += $ns
        "{0},{1},{2},single_ns_per_call,{3},ns" -f $r, $Label, $freq, ([math]::Round($ns,4)) | Out-File -FilePath $csv -Append -Encoding utf8
        Write-Host ("   run {0}: {1,10:N2} ns/call   ({2:N0} calls/sec)" -f $r, $ns, (1e9/$ns))
    }
    $sStat = Get-Stats $single

    # ---- Multi-thread aggregate throughput (calls/sec) ----
    Write-Host ""
    Write-Host (" Multi-thread aggregate throughput ({0} threads, {1:N0} calls each):" -f $Threads, $perThread) -ForegroundColor Green
    $multi = @()
    for ($r = 1; $r -le $Repetitions; $r++) {
        $cps = [QpcBench]::BenchMultiCallsPerSec($perThread, $Threads)
        $multi += $cps
        "{0},{1},{2},multi_calls_per_sec,{3},calls/sec" -f $r, $Label, $freq, ([math]::Round($cps,0)) | Out-File -FilePath $csv -Append -Encoding utf8
        Write-Host ("   run {0}: {1,14:N0} calls/sec" -f $r, $cps)
    }
    $mStat = Get-Stats $multi

    # ---- Concurrency gain (reveals shared-resource serialization) ----
    $singleCps = 1e9 / $sStat.Median
    $gain      = $mStat.Median / $singleCps

    # -----------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------
    Write-Host ""
    Write-Host "-------------------------- SUMMARY ---------------------------" -ForegroundColor Cyan
    Write-Host (" Single-thread ns/call : median {0:N2}  mean {1:N2}  min {2:N2}  max {3:N2}  sd {4:N2}  CoV {5:N1}%" -f `
                $sStat.Median, $sStat.Mean, $sStat.Min, $sStat.Max, $sStat.StdDev, $sStat.CoV)
    Write-Host ("   -> single-thread throughput (median): {0:N0} calls/sec" -f $singleCps)
    Write-Host (" Multi-thread calls/sec: median {0:N0}  mean {1:N0}  min {2:N0}  max {3:N0}  CoV {4:N1}%" -f `
                $mStat.Median, $mStat.Mean, $mStat.Min, $mStat.Max, $mStat.CoV)
    Write-Host ("   -> concurrency gain vs 1 thread ({0} threads): {1:N2}x" -f $Threads, $gain)
    Write-Host ""
    Write-Host " HOW TO READ THIS (per Microsoft's QPC documentation):" -ForegroundColor Magenta
    Write-Host "   Register-class source (TSC path, healthy default):"
    Write-Host "     - ns/call roughly in the tens of nanoseconds or less"
    Write-Host "     - concurrency gain clearly ABOVE 1x (more threads -> more total reads)"
    Write-Host "   Forced platform timer (HPET / ACPI PM, shared + kernel transition):"
    Write-Host "     - ns/call in the hundreds of ns, typically ~800-1000 ns"
    Write-Host "     - concurrency gain around or BELOW 1x (threads queue on one shared timer)"
    Write-Host "   Absolute values vary by hardware. The rigorous comparison is THIS"
    Write-Host "   machine, state A vs state B, same settings. The DELTA is the evidence."
    Write-Host ""
    "summary,{0},{1},single_median_ns,{2},ns"        -f $Label, $freq, ([math]::Round($sStat.Median,4)) | Out-File -FilePath $csv -Append -Encoding utf8
    "summary,{0},{1},single_cov_pct,{2},pct"         -f $Label, $freq, ([math]::Round($sStat.CoV,2))    | Out-File -FilePath $csv -Append -Encoding utf8
    "summary,{0},{1},multi_median_cps,{2},calls/sec" -f $Label, $freq, ([math]::Round($mStat.Median,0)) | Out-File -FilePath $csv -Append -Encoding utf8
    "summary,{0},{1},concurrency_gain_x,{2},ratio"   -f $Label, $freq, ([math]::Round($gain,3))         | Out-File -FilePath $csv -Append -Encoding utf8

    Write-Host (" CSV written: {0}" -f (Resolve-Path -LiteralPath $csv)) -ForegroundColor Green
    Write-Host "==============================================================" -ForegroundColor Cyan

    try { $proc.PriorityClass = $oldPriority } catch { }
    Exit-Script 0
}
catch {
    try { $proc.PriorityClass = $oldPriority } catch { }
    Write-Host ""
    Write-Host " ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Exit-Script 1
}
