<#
================================================================================
 Change-Timer-Settings.ps1  |  Alchemy Tweaks - HPET Debunk Package
================================================================================
 PURPOSE
   Safe, reversible controller for the HPET / useplatformclock test matrix.
   - Shows the CURRENT timer state (BCD overrides + QueryPerformanceFrequency).
   - ALWAYS backs up the BCD store (bcdedit /export) before any change.
   - Applies a named test STATE with the correct bcdedit commands.
   - Reverts cleanly to Windows auto-selection using /deletevalue (NOT "no").
   - Self-elevates: if not started as Administrator, it relaunches itself and
     asks for UAC approval, so it always runs with full privileges.

 FACTS THIS TOOL ENCODES (verified against Microsoft Learn, 2026-07-03)
   - useplatformclock  "Forces the use of the platform clock as the system's
     performance counter." Microsoft: "should only be used for debugging".
   - useplatformtick   "Forces the clock to be backed by a platform source,
     no synthetic timers are allowed" (Windows 8+). Debugging only.
   - disabledynamictick "Enables and disables dynamic timer tick feature."
     Debugging only.
   - tscsyncpolicy     [Default|Legacy|Enhanced] "Controls the time stamp
     counter synchronization policy." Debugging only.
   - The clean Windows default is restored with `bcdedit /deletevalue`, which
     REMOVES the override so Windows auto-selects the best counter. Setting
     `useplatformclock no` writes an explicit value instead - that is NOT the
     documented way to return to default.
   - "After modifying BCD data, a normal shutdown and reboot is necessary."
     Verify the state AFTER reboot; never trust "the command succeeded".
   Sources:
     https://learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--set
     https://learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--deletevalue
     https://learn.microsoft.com/windows-hardware/drivers/devtest/editing-boot-options
     https://learn.microsoft.com/windows/win32/sysinfo/acquiring-high-resolution-time-stamps

 REVERSIBILITY (correcting a common myth)
   These changes are FULLY REVERSIBLE. If a state misbehaves, revert with
   /deletevalue + reboot, or restore the exact backup:
       bcdedit /import "<backup .bcd file>"
   You do NOT need to reinstall Windows.

 SAFETY
   - Microsoft: "Before setting BCDEdit options you might need to disable or
     suspend BitLocker and Secure Boot." This script WARNS if BitLocker is on.
   - This script NEVER reboots unless you pass -Reboot AND confirm.
   - Every Apply/Revert takes a fresh timestamped backup first, automatically.

 USAGE (easiest: double-click the matching .cmd launcher in this folder)
   powershell -ExecutionPolicy Bypass -File .\Change-Timer-Settings.ps1 -Action Status
   powershell -ExecutionPolicy Bypass -File .\Change-Timer-Settings.ps1 -Action Backup
   powershell -ExecutionPolicy Bypass -File .\Change-Timer-Settings.ps1 -Action Apply -State PlatformClock
   powershell -ExecutionPolicy Bypass -File .\Change-Timer-Settings.ps1 -Action Revert

 STATES
   Default        -> /deletevalue all four options   (true Windows baseline)
   PlatformClock  -> useplatformclock yes            (the core HPET myth)
   DynamicTick    -> disabledynamictick yes          (separate tick myth)
   PlatformTick   -> useplatformtick   yes           (platform-source myth)
   FullMyth       -> all three of the above at once

 EXTRA SWITCHES
   -Force    skip the YES confirmation prompts (for scripted use)
   -NoPause  do not wait for Enter before the window closes (for scripted use)
   -Reboot   offer to reboot after a successful Apply/Revert
================================================================================
#>

[CmdletBinding()]
param(
    [ValidateSet("Status","Backup","Apply","Revert")]
    [string] $Action = "Status",

    [ValidateSet("Default","PlatformClock","DynamicTick","PlatformTick","FullMyth")]
    [string] $State  = "Default",

    [string] $OutDir = "",
    [switch] $Reboot,
    [switch] $Force,
    [switch] $NoPause,

    # Internal marker: set automatically when the script relaunches itself
    # elevated. Do not pass it yourself.
    [Parameter(DontShow)]
    [switch] $Elevated
)

$ErrorActionPreference = "Stop"
$timerOptions = @("useplatformclock","useplatformtick","disabledynamictick","tscsyncpolicy")

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Exit-Script([int]$code) {
    if (-not $NoPause) {
        Write-Host ""
        Read-Host " Press Enter to close this window" | Out-Null
    }
    exit $code
}

# ---------------------------------------------------------------------------
# Self-elevation: relaunch with full Administrator privileges via UAC.
# ---------------------------------------------------------------------------
if (-not (Test-Admin)) {
    Write-Host ""
    Write-Host " This tool needs Administrator rights (bcdedit requires them)." -ForegroundColor Yellow
    Write-Host " Requesting elevation - please approve the UAC prompt..." -ForegroundColor Yellow

    $psExe = if ($PSVersionTable.PSEdition -eq "Core") { "pwsh.exe" } else { "powershell.exe" }
    $argList = @("-NoProfile","-ExecutionPolicy","Bypass","-File", ('"{0}"' -f $PSCommandPath))
    foreach ($kv in $PSBoundParameters.GetEnumerator()) {
        if ($kv.Value -is [System.Management.Automation.SwitchParameter]) {
            if ($kv.Value) { $argList += ("-{0}" -f $kv.Key) }
        } else {
            $argList += ("-{0}" -f $kv.Key)
            $argList += ('"{0}"' -f $kv.Value)
        }
    }
    $argList += "-Elevated"

    try {
        Start-Process -FilePath $psExe -Verb RunAs -ArgumentList ($argList -join " ") | Out-Null
        Write-Host " Elevated window launched. This window can be closed." -ForegroundColor Green
        exit 0
    } catch {
        Write-Host " Elevation was declined or failed. Nothing was changed." -ForegroundColor Red
        Exit-Script 1
    }
}

# From here on we are guaranteed to run elevated.
Set-Location -LiteralPath $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($OutDir)) { $OutDir = Join-Path $PSScriptRoot "AlchemyHPET" }

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Runs bcdedit with the error stream captured WITHOUT tripping PowerShell 5.1's
# "native stderr + ErrorActionPreference=Stop" termination behavior.
function Invoke-Bcdedit([string[]]$BcdArgs) {
    $eap = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $out  = & bcdedit @BcdArgs 2>&1
        $code = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $eap
    }
    $text = @($out | ForEach-Object { "$_" }) -join [Environment]::NewLine
    return [pscustomobject]@{ ExitCode = $code; Output = $text }
}

function Get-Qpf {
    if (-not ("AlchemyHpet.QpfHelper" -as [type])) {
        $sig = '[DllImport("kernel32.dll")] public static extern bool QueryPerformanceFrequency(out long f);'
        Add-Type -MemberDefinition $sig -Name QpfHelper -Namespace AlchemyHpet | Out-Null
    }
    $f = [long]0
    [void][AlchemyHpet.QpfHelper]::QueryPerformanceFrequency([ref]$f)
    return $f
}

function Get-QpfReading([long]$freq) {
    # QueryPerformanceFrequency is an INDICATOR only. Microsoft: under a
    # hypervisor v1.0 interface, or always in some newer versions of Windows,
    # QPF is fixed to 10 MHz regardless of the hardware source.
    switch ($freq) {
        10000000 { return "10.000 MHz -> standard fixed value on modern Windows. Indicator only, NOT proof of the source." }
        3579545  { return "3.579545 MHz -> ACPI PM timer (platform timer)." }
        14318180 { return "14.318 MHz -> HPET (platform timer)." }
        default {
            if ($freq -ge 1000000000) { return "$([math]::Round($freq/1e6,3)) MHz -> raw TSC frequency (older QPC behavior)." }
            elseif ($freq -ge 12000000 -and $freq -le 30000000) { return "$([math]::Round($freq/1e6,3)) MHz -> HPET-class platform timer (frequency varies by chipset)." }
            else { return "$([math]::Round($freq/1e6,6)) MHz -> non-standard; confirm with the read-cost benchmark." }
        }
    }
}

function Get-TimerState {
    $res = Invoke-Bcdedit @("/enum","{current}")
    if ($res.ExitCode -ne 0) { throw "bcdedit /enum failed: $($res.Output)" }
    $lines  = $res.Output -split "\r?\n"
    $result = [ordered]@{}
    foreach ($opt in $timerOptions) {
        $line = $lines | Where-Object { $_ -match ("^\s*{0}\s+\S" -f [regex]::Escape($opt)) } | Select-Object -First 1
        if ($line) { $result[$opt] = ($line -replace ("^\s*{0}\s+" -f [regex]::Escape($opt)), "").Trim() }
        else       { $result[$opt] = "(not set -> Windows auto-selects; this is the default)" }
    }
    return $result
}

function Show-TimerOverrides {
    $st = Get-TimerState
    foreach ($k in $st.Keys) { Write-Host ("   {0,-20}: {1}" -f $k, $st[$k]) }
}

function Show-Status {
    $freq = Get-Qpf
    Write-Host ""
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host " Alchemy - HPET / Timer State" -ForegroundColor Cyan
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host (" Time                      : {0}" -f (Get-Date))
    Write-Host (" QueryPerformanceFrequency : {0:N0} Hz" -f $freq) -ForegroundColor Yellow
    Write-Host ("   -> {0}" -f (Get-QpfReading $freq)) -ForegroundColor Yellow
    Write-Host ""
    Write-Host " BCD timer overrides (bcdedit /enum {current}):" -ForegroundColor Green
    Show-TimerOverrides
    Write-Host ""
    Write-Host " NOTE: QPF is an INDICATOR, not definitive proof of the QPC source." -ForegroundColor Magenta
    Write-Host "       The decisive test is Measure-Timer-Speed.ps1 (ns per call)." -ForegroundColor Magenta
    Write-Host "==============================================================" -ForegroundColor Cyan
}

function New-BcdBackup {
    if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $bak   = Join-Path $OutDir ("bcd-backup-{0}.bcd" -f $stamp)

    $res = Invoke-Bcdedit @("/export", $bak)
    if ($res.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $bak)) {
        throw "BCD backup FAILED ($($res.Output)). Aborting - no changes were made."
    }
    # Also save a human-readable snapshot next to the binary backup.
    $enum = Invoke-Bcdedit @("/enum","{current}")
    $enum.Output | Out-File -FilePath (Join-Path $OutDir ("bcd-enum-{0}.txt" -f $stamp)) -Encoding utf8

    Write-Host (" BCD backup created: {0}" -f $bak) -ForegroundColor Green
    Write-Host ("   Restore any time with:  bcdedit /import `"{0}`"" -f $bak) -ForegroundColor Green
    return $bak
}

function Show-BitLockerWarning {
    try {
        $bl = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction SilentlyContinue
        if ($bl -and "$($bl.ProtectionStatus)" -eq "On") {
            Write-Host ""
            Write-Host " WARNING: BitLocker is ON for $($env:SystemDrive)." -ForegroundColor Red
            Write-Host "   Microsoft: you might need to suspend BitLocker / Secure Boot before BCD edits." -ForegroundColor Red
            Write-Host "   Have your recovery key ready, or suspend for one reboot with:" -ForegroundColor Red
            Write-Host "     manage-bde -protectors -disable $env:SystemDrive -RebootCount 1" -ForegroundColor Red
            Write-Host ""
        }
    } catch { }
}

function Get-StateCommands([string]$s) {
    switch ($s) {
        "Default"       { return @(
            @("/deletevalue","useplatformclock"),
            @("/deletevalue","useplatformtick"),
            @("/deletevalue","disabledynamictick"),
            @("/deletevalue","tscsyncpolicy")) }
        "PlatformClock" { return @(
            @("/deletevalue","useplatformtick"),
            @("/deletevalue","disabledynamictick"),
            @("/deletevalue","tscsyncpolicy"),
            @("/set","useplatformclock","yes")) }
        "DynamicTick"   { return @(
            @("/deletevalue","useplatformclock"),
            @("/deletevalue","useplatformtick"),
            @("/deletevalue","tscsyncpolicy"),
            @("/set","disabledynamictick","yes")) }
        "PlatformTick"  { return @(
            @("/deletevalue","useplatformclock"),
            @("/deletevalue","disabledynamictick"),
            @("/deletevalue","tscsyncpolicy"),
            @("/set","useplatformtick","yes")) }
        "FullMyth"      { return @(
            @("/deletevalue","tscsyncpolicy"),
            @("/set","useplatformclock","yes"),
            @("/set","disabledynamictick","yes"),
            @("/set","useplatformtick","yes")) }
    }
}

function Invoke-StateCommands([object[]]$cmds) {
    $failed = $false
    foreach ($c in $cmds) {
        Write-Host ("   > bcdedit {0}" -f ($c -join " ")) -ForegroundColor Gray
        $res = Invoke-Bcdedit $c
        if ($res.ExitCode -ne 0) {
            if ($c[0] -eq "/deletevalue") {
                # Deleting an option that is not set fails by design - that
                # simply means it is already at the Windows default.
                Write-Host "     (option was not set - already at default, nothing to remove)" -ForegroundColor DarkGray
            } else {
                Write-Host ("     FAILED: {0}" -f $res.Output) -ForegroundColor Red
                $failed = $true
            }
        }
    }
    return (-not $failed)
}

function Confirm-OrExit([string]$msg) {
    if ($Force) { return }
    Write-Host ""
    $ans = Read-Host (" $msg  Type YES to continue")
    if ($ans -cne "YES") {
        Write-Host " Cancelled - no changes were made." -ForegroundColor Yellow
        Exit-Script 0
    }
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
try {
    switch ($Action) {

        "Status" {
            Show-Status
        }

        "Backup" {
            New-BcdBackup | Out-Null
        }

        { $_ -in @("Apply","Revert") } {
            $targetState = if ($Action -eq "Revert") { "Default" } else { $State }

            Write-Host ""
            Write-Host "==============================================================" -ForegroundColor Cyan
            Write-Host (" Alchemy - {0}" -f $(if ($Action -eq "Revert") {"Revert to Windows default"} else {"Apply state: $State"})) -ForegroundColor Cyan
            Write-Host "==============================================================" -ForegroundColor Cyan

            Write-Host ""
            Write-Host " Current state BEFORE any change:" -ForegroundColor Green
            Show-TimerOverrides

            Show-BitLockerWarning
            $backup = New-BcdBackup      # ALWAYS back up before touching BCD

            $cmds = Get-StateCommands $targetState
            Write-Host ""
            Write-Host (" About to apply state '{0}' with these commands:" -f $targetState) -ForegroundColor Yellow
            foreach ($c in $cmds) { Write-Host ("   bcdedit {0}" -f ($c -join " ")) }
            Confirm-OrExit "This edits your boot configuration and needs a reboot to take effect."

            Write-Host ""
            $ok = Invoke-StateCommands $cmds

            Write-Host ""
            Write-Host " State AFTER writing (pre-reboot - NOT in effect yet):" -ForegroundColor Green
            Show-TimerOverrides

            if (-not $ok) {
                Write-Host ""
                Write-Host " One or more commands FAILED - review the output above." -ForegroundColor Red
                Write-Host (" You can restore the exact previous state with:  bcdedit /import `"{0}`"" -f $backup) -ForegroundColor Red
                Exit-Script 1
            }

            Write-Host ""
            Write-Host " *** A REBOOT IS REQUIRED for this state to take effect. ***" -ForegroundColor Magenta
            Write-Host " After reboot, VERIFY with:  -Action Status   and   Measure-Timer-Speed.ps1" -ForegroundColor Magenta
            Write-Host (" Backup for rollback: {0}" -f $backup) -ForegroundColor Green

            if ($Reboot) {
                Confirm-OrExit "Reboot NOW?"
                Write-Host " Rebooting in 5 seconds... (Ctrl+C to abort)" -ForegroundColor Red
                Start-Sleep -Seconds 5
                Restart-Computer -Force
            } else {
                Write-Host " (No -Reboot flag: reboot manually when ready.)" -ForegroundColor DarkYellow
                Write-Host " Use RESTART, not Shut down: with Fast Startup enabled, 'Shut down +" -ForegroundColor DarkYellow
                Write-Host " power on' is NOT a full boot, so the change would not take effect." -ForegroundColor DarkYellow
            }
        }
    }
    Exit-Script 0
}
catch {
    Write-Host ""
    Write-Host " ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host " No further changes were made." -ForegroundColor Red
    Exit-Script 1
}
