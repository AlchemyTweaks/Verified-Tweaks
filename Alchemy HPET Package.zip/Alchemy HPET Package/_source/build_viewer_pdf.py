# -*- coding: utf-8 -*-
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                HRFlowable, ListFlowable, ListItem, PageBreak)
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", "Alchemy HPET Package", "HPET-Explained.pdf")
FD = "/usr/share/fonts/truetype/dejavu"
pdfmetrics.registerFont(TTFont("DJ",  os.path.join(FD,"DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DJB", os.path.join(FD,"DejaVuSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("DJM", os.path.join(FD,"DejaVuSansMono.ttf")))

NAVY=colors.HexColor("#0F1B2D"); BLUE=colors.HexColor("#1E6FE0"); GREEN=colors.HexColor("#1F9D57")
RED=colors.HexColor("#C0392B"); AMBER=colors.HexColor("#B7791F"); GREYBG=colors.HexColor("#F2F4F7"); GREENBG=colors.HexColor("#EAF7EF")
BLUEBG=colors.HexColor("#EAF2FD"); LN=colors.HexColor("#D6DBE2"); TEXT=colors.HexColor("#1A2230")
MUTED=colors.HexColor("#5A6472"); W=colors.white

ss=getSampleStyleSheet()
body=ParagraphStyle("b",parent=ss["Normal"],fontName="DJ",fontSize=10.2,leading=15,textColor=TEXT,spaceAfter=7,alignment=TA_LEFT)
h=ParagraphStyle("h",fontName="DJB",fontSize=12.5,leading=16,textColor=NAVY,spaceBefore=11,spaceAfter=4)
li=ParagraphStyle("li",parent=body,spaceAfter=4,leading=14.5)
small=ParagraphStyle("s",fontName="DJ",fontSize=8.5,leading=12,textColor=MUTED)
th=ParagraphStyle("th",fontName="DJB",fontSize=8.8,leading=11.5,textColor=W)
td=ParagraphStyle("td",fontName="DJ",fontSize=8.8,leading=12,textColor=TEXT)
tdb=ParagraphStyle("tdb",parent=td,fontName="DJB")

def P(t,st=body): return Paragraph(t,st)
def bullets(items):
    return ListFlowable([ListItem(Paragraph(t,li),leftIndent=12,value="•") for t in items],
        bulletType="bullet",start="•",leftIndent=12,bulletFontName="DJ",bulletFontSize=9)
def box(title,text,accent=BLUE,bg=GREYBG):
    if isinstance(bg,str): bg=colors.HexColor(bg)
    inner=[]
    if title: inner.append(Paragraph("<b>%s</b>"%title,ParagraphStyle("bt",fontName="DJB",fontSize=10.2,leading=14,textColor=accent,spaceAfter=3)))
    inner.append(Paragraph(text,ParagraphStyle("bb",fontName="DJ",fontSize=10,leading=14.5,textColor=TEXT)))
    t=Table([[inner]],colWidths=[170*mm])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),bg),("LINEBEFORE",(0,0),(0,-1),3.5,accent),
        ("LEFTPADDING",(0,0),(-1,-1),11),("RIGHTPADDING",(0,0),(-1,-1),11),
        ("TOPPADDING",(0,0),(-1,-1),9),("BOTTOMPADDING",(0,0),(-1,-1),9)]))
    return t
def table(data,cw):
    t=Table(data,colWidths=cw,repeatRows=1)
    cmds=[("VALIGN",(0,0),(-1,-1),"MIDDLE"),("BACKGROUND",(0,0),(-1,0),NAVY),
          ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
          ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
          ("LINEBELOW",(0,0),(-1,-1),0.4,LN),("BOX",(0,0),(-1,-1),0.4,LN)]
    for r in range(1,len(data)):
        if r%2==0: cmds.append(("BACKGROUND",(0,r),(-1,r),colors.HexColor("#F7F9FC")))
    t.setStyle(TableStyle(cmds)); return t
def onpage(c,d):
    c.saveState(); w,hh=A4
    c.setStrokeColor(LN); c.setLineWidth(.5); c.line(18*mm,12*mm,w-18*mm,12*mm)
    c.setFont("DJ",7.4); c.setFillColor(MUTED)
    c.drawString(18*mm,8.4*mm,"HPET and the Windows timer tweaks - measured results")
    c.drawRightString(w-18*mm,8.4*mm,"Page %d"%d.page); c.restoreState()

S=[]
band=Table([[Paragraph("MEASURED ON REAL HARDWARE, NOT COPIED FROM A GUIDE",
        ParagraphStyle("x",fontName="DJB",fontSize=8.8,textColor=colors.HexColor("#8Fc0FF"),leading=12))],
     [Paragraph("HPET and the Windows Timer Tweaks",
        ParagraphStyle("y",fontName="DJB",fontSize=19,textColor=W,leading=23,spaceBefore=3))],
     [Paragraph("What we tested, what the numbers showed, and what it means for your PC",
        ParagraphStyle("z",fontName="DJ",fontSize=10,textColor=colors.HexColor("#C9D6E8"),leading=14,spaceBefore=3))]],
    colWidths=[170*mm])
band.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),NAVY),("LEFTPADDING",(0,0),(-1,-1),13),
  ("RIGHTPADDING",(0,0),(-1,-1),13),("TOPPADDING",(0,0),(0,0),12),("BOTTOMPADDING",(0,-1),(-1,-1),12),
  ("TOPPADDING",(0,1),(-1,-1),0)]))
S.append(band); S.append(Spacer(1,10))

S.append(box("THE SHORT VERSION",
  "Leave the Windows default alone. Every timer setting we forced was either neutral or worse. One of them made the "
  "test PC unplayable. None of them produced a repeatable gain in frame rate, smoothness or input latency.",GREEN,GREENBG))
S.append(Spacer(1,5))

S.append(P("What people claim",h))
S.append(P("Tuning guides and optimizer scripts often tell you to force a timer called HPET, usually with a command like "
  "<font name='DJM'>bcdedit /set useplatformclock yes</font>, promising more FPS, lower input lag and less stutter. "
  "The claim is repeated everywhere but rarely tested properly."))

S.append(P("What these settings actually change",h))
S.append(P("Games ask Windows for the time thousands of times per second through an API called QueryPerformanceCounter. "
  "Windows normally answers using a counter built into the CPU, which is very fast to read. The settings below force it "
  "to use older hardware timers on the motherboard instead, or change how ticks and clock synchronisation work. "
  "Microsoft documents all four as debugging options, not performance settings."))
S.append(table([
  [Paragraph("Setting",th),Paragraph("What it does",th)],
  [Paragraph("useplatformclock",tdb),Paragraph("Forces the timer that games read onto a slower motherboard clock.",td)],
  [Paragraph("useplatformtick",tdb),Paragraph("Forces the system tick onto a hardware source.",td)],
  [Paragraph("disabledynamictick",tdb),Paragraph("Stops Windows from skipping timer ticks while idle.",td)],
  [Paragraph("tscsyncpolicy",tdb),Paragraph("Changes how CPU clocks are lined up during startup.",td)],
],[42*mm,128*mm]))

S.append(P("How it was tested",h))
S.append(bullets([
  "Intel Core i5-10400F, Radeon RX 5700 XT, Windows 11 Pro 25H2, 1080p at 144 Hz.",
  "Fortnite on a static custom map, the identical scene for every setting.",
  "52 recorded runs of 65 seconds each, with the first 5 seconds discarded.",
  "Each setting was applied, the PC fully restarted, and the setting verified before recording.",
  "Four separate kinds of measurement: timer read cost, frame rate and frame times, hardware click-to-photon latency (503 shots per setting), and kernel traces.",
]))

S.append(P("What the measurements showed",h))
S.append(table([
  [Paragraph("Setting",th),Paragraph("Timer read cost",th),Paragraph("Average FPS",th),Paragraph("Result",th)],
  [Paragraph("Windows default",tdb),Paragraph("21.6 ns",td),Paragraph("300.5",td),Paragraph("<font color='#1F9D57'><b>Best supported option</b></font>",td)],
  [Paragraph("useplatformclock yes",tdb),Paragraph("5,887 ns",td),Paragraph("<font color='#C0392B'>not measurable</font>",td),Paragraph("<font color='#C0392B'><b>273x slower timer; PC unusable</b></font>",td)],
  [Paragraph("All three forced",tdb),Paragraph("5,313 ns",td),Paragraph("<font color='#C0392B'>not measurable</font>",td),Paragraph("<font color='#C0392B'><b>Same collapse</b></font>",td)],
  [Paragraph("useplatformtick yes",tdb),Paragraph("21.4 ns",td),Paragraph("284.5",td),Paragraph("<font color='#C0392B'><b>5.3% slower, seen twice</b></font>",td)],
  [Paragraph("disabledynamictick yes",tdb),Paragraph("20.8 ns",td),Paragraph("302.8",td),Paragraph("No proven gain",td)],
  [Paragraph("tscsyncpolicy Default",tdb),Paragraph("20.5 ns",td),Paragraph("300.6",td),Paragraph("Same as leaving it unset",td)],
  [Paragraph("tscsyncpolicy Legacy / Enhanced",tdb),Paragraph("20.6 ns",td),Paragraph("287.3 / 286.4",td),Paragraph("<font color='#B7791F'><b>Not established, see below</b></font>",td)],
],[46*mm,26*mm,26*mm,72*mm]))
S.append(Spacer(1,6))
S.append(box("TWO OF THESE SETTINGS COULD NOT BE MEASURED AT ALL",
  "With <b>useplatformclock</b> forced, both on its own and again with all three switches together, the PC was simply not "
  "usable: the game ran at roughly 20 to 30 FPS and stalled constantly, so no frame rate, frame time or input latency "
  "recording was possible for either configuration. What those two rows report is the timer read cost, which is a direct "
  "measurement taken outside the game, together with what was plainly visible on screen. The absence of data is not a gap "
  "in the testing; it is the result.", RED, "#FDECE9"))
S.append(Spacer(1,6))
S.append(P("Two details worth knowing. The +0.78% that dynamic tick appeared to gain is smaller than the 1.71% difference we "
  "measured between two runs of the <i>same</i> default configuration, so it is below the noise of the experiment rather than a "
  "real improvement. And the hardware input-latency test showed no setting that was reliably better than default."))

S.append(Spacer(1,6))
S.append(box("CORRECTION: THE tscsyncpolicy RESULT DOES NOT HOLD UP",
  "In the first round of testing, Legacy and Enhanced came out about 4 to 5 percent below baseline. On closer analysis that "
  "difference cannot be attributed to the setting, and this document corrects the earlier reading.<br/><br/>"
  "<b>The measurement contradicts itself.</b> The same setting, Enhanced, measured 286.4 FPS in one session and 297.1 FPS in "
  "another, with nothing changed between them. That is a 3.75 percent swing from an identical configuration, which is as large "
  "as the effect being claimed. Two baseline sessions also differed by 1.71 percent. Within a single boot the runs are very "
  "consistent, better than one percent, but between boots this machine varies by several percent, and each setting was tested "
  "in only one boot.<br/><br/>"
  "<b>There is no mechanism either.</b> The frame-rate drop tracked the CPU work per frame almost exactly, 4.35 percent fewer "
  "frames against 4.32 percent more CPU time per frame. A setting that only affects how processor clocks are aligned during "
  "startup has no way to make each frame cost more CPU afterwards. The timer read cost was also identical across all three "
  "values, and the machine state was the same in every session, with the CPU at the same 3,978 MHz throughout.<br/><br/>"
  "<b>On top of that, the setting may not do anything at all on current Windows.</b> Reverse-engineering of the Windows "
  "boot-option parser shows the code that reads this option present in older builds and absent in the current one, and the "
  "related kernel symbol no longer resolves.<br/><br/>"
  "<b>The honest conclusion:</b> no effect from tscsyncpolicy was demonstrated. What was measured is the normal variation "
  "between one restart and the next.", AMBER, "#FEF6E7"))
S.append(Spacer(1,6))
S.append(P("Why the useplatformtick result survives the same scrutiny", h))
S.append(P("It was measured across two separate boots that gave 284.3 and 284.1 FPS, a spread of one tenth of a percent, with "
  "the baseline session recorded between them in time. It also has a mechanism: forcing the tick raised CPU work per frame by "
  "5.75 percent, which matches the 5.42 percent frame-rate loss. That is what a real effect looks like, and it is the "
  "difference between the two cases."))
S.append(Spacer(1,4))
S.append(P("What it means",h))
S.append(P("Forcing the platform clock does not make anything faster. It swaps a timer that takes about 22 billionths of a "
  "second to read for one that takes roughly 5.9 millionths, which is why the game became unplayable rather than smoother. "
  "The other switches ranged from harmless to a measurable 5% frame-rate loss. Nothing gained anything."))

S.append(box("WHAT YOU SHOULD DO",
  "If you have never touched these settings, do nothing. You are already on the fast default path. If you did apply them from "
  "a guide, open the Timer Settings Menu in this folder: it shows what is set on your PC, whether that is the Windows default, "
  "and whether it still matches how your PC was before you started. It can undo any of it.",
  BLUE,BLUEBG))
S.append(Spacer(1,5))

S.append(P("Check your own PC",h))
S.append(P("Do not take these numbers on trust. The tools used for this testing are in this folder. The menu records your original "
  "settings the first time you open it, backs up the boot configuration before every change, and can always put things back. "
  "The second launcher measures your own timer read cost. Different hardware can behave differently, which is the whole point "
  "of measuring instead of copying."))

S.append(PageBreak())
S.append(P("Sources and further reading",h))
S.append(P("Everything consulted while preparing this test. Official documentation defines how the mechanisms work; the "
  "independent measurements and community links are included for completeness. The conclusions come from the measurements "
  "on the previous pages, not from any single source."))

def refhead(t): return Paragraph(t, ParagraphStyle("rh",fontName="DJB",fontSize=9.3,leading=12,textColor=BLUE,spaceBefore=7,spaceAfter=3))
def ref(t):     return Paragraph(t, ParagraphStyle("rf",fontName="DJ",fontSize=8.3,leading=11.4,textColor=TEXT,spaceAfter=3.5,leftIndent=11,firstLineIndent=-11))

S.append(refhead("Official platform documentation"))
for t in [
 "Microsoft Learn. <i>Acquiring high-resolution time stamps.</i> How Windows picks the counter behind "
 "QueryPerformanceCounter, why platform timers cost more to read than the CPU counter, and why the reported frequency does "
 "not reliably identify the source.<br/>learn.microsoft.com/windows/win32/sysinfo/acquiring-high-resolution-time-stamps",
 "Microsoft Learn. <i>BCDEdit /set.</i> Reference for useplatformclock, useplatformtick, disabledynamictick and "
 "tscsyncpolicy, each documented as an option for debugging.<br/>learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--set",
 "Microsoft Learn. <i>BCDEdit /deletevalue.</i> The documented way to remove an option and return to the default.<br/>"
 "learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--deletevalue",
 "Microsoft Learn. <i>Editing boot options.</i> Boot changes apply only after a restart.<br/>"
 "learn.microsoft.com/windows-hardware/drivers/devtest/editing-boot-options",
 "Microsoft Learn. <i>QueryPerformanceCounter function.</i> The API games use to read high-resolution time.<br/>"
 "learn.microsoft.com/windows/win32/api/profileapi/nf-profileapi-queryperformancecounter",
 "Microsoft Learn. <i>timeBeginPeriod.</i> Timer resolution, a separate subject often confused with these settings, and "
 "one that does not affect the counter measured here.<br/>learn.microsoft.com/windows/win32/api/timeapi/nf-timeapi-timebeginperiod",
 "Microsoft Learn. <i>ACPI system description tables</i> and <i>Acpi.sys.</i> How firmware exposes platform timers, and why "
 "the Device Manager entry is not the control people assume.<br/>learn.microsoft.com/windows-hardware/drivers/bringup/acpi-system-description-tables",
 "Microsoft Learn. <i>Tracelog and DPC/ISR measurement.</i> Basis for the kernel trace work.<br/>"
 "learn.microsoft.com/windows-hardware/drivers/devtest/tracelog",
 "Intel. <i>IA-PC HPET (High Precision Event Timers) Specification, revision 1.0a.</i> What HPET is, how the operating "
 "system finds it, and its minimum frequency.",
]: S.append(ref(t))

S.append(refhead("Independent measurements of the same mechanism"))
for t in [
 "Red Hat. <i>Using hardware clocks for system timestamping</i> (Enterprise Linux for Real Time). Ten million reads: about "
 "0.6 s on the CPU counter, 12 s on HPET, 24 s on the ACPI PM timer. Different operating system, same physical "
 "conclusion.<br/>docs.redhat.com",
 "VMware. <i>Timekeeping in VMware Virtual Machines.</i> HPET read latency in the microsecond range; the specification does "
 "not require the timer to be fast to read.<br/>vmware.com/docs/vmware_timekeeping",
]: S.append(ref(t))

S.append(refhead("Independent technical analysis"))
for t in [
 "valleyofdoom, <i>PC-Tuning</i> research notes. Kernel debugger analysis of what tscsyncpolicy changes, and that its "
 "Default token equals leaving the option unset.<br/>github.com/valleyofdoom/PC-Tuning",
 "Noverse documentation, <i>BCD Edits.</i> Reverse-engineered boot timer elements and kernel pseudocode, including that the "
 "tscsyncpolicy symbol appears absent on the latest Windows builds. Independently corroborated by decompilation of the "
  "boot-option parser from two builds compared side by side.<br/>noverse.dev/docs",
]: S.append(ref(t))

S.append(refhead("Community discussions referenced"))
S.append(ref("Where these claims circulate, cited so you can read the original arguments rather than as evidence: TechPowerUp "
  "forums, <i>Revisiting HPET bcdedit tweaks</i> and the TimerBench tool discussed there; Blur Busters forums, "
  "useplatformclock and tscsyncpolicy threads; Melody's Tweaks, <i>Misconceptions about timers (HPET, TSC, PMT).</i>"))

S.append(refhead("Measurement tools used"))
S.append(ref("Intel GameTechDev <i>PresentMon</i> 2.5.1 for frame timing (github.com/GameTechDev/PresentMon) &middot; "
  "<i>OSLTT</i> open source latency tester for hardware click-to-photon &middot; Windows Performance Recorder and xperf for "
  "kernel traces &middot; a purpose-written QueryPerformanceCounter read-cost benchmark, included in this folder so the "
  "timer measurement can be repeated on any PC."))

S.append(Spacer(1,6))
S.append(P("Measurements taken 19 July 2026 on the system described earlier in this document.",small))

doc=SimpleDocTemplate(OUT,pagesize=A4,leftMargin=18*mm,rightMargin=18*mm,topMargin=15*mm,bottomMargin=16*mm,
    title="HPET and the Windows Timer Tweaks",author="Alchemy Tweaks",subject="Measured results")
doc.build(S,onFirstPage=onpage,onLaterPages=onpage)
print("WROTE",OUT,os.path.getsize(OUT),"bytes")
