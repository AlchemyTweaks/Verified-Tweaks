# -*- coding: utf-8 -*-
"""
PUBLIC / audience companion (neutral explainer): HPET_for_FPS_Explained_Simply.pdf
Explains what the video tests & shows, the background, with citations + bibliography.
No recommendations except (a) what Microsoft states and (b) the author's position:
measure it yourself. Neutral stance throughout. Output goes to the parent package folder.
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                HRFlowable, ListFlowable, ListItem)
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "HPET_for_FPS_Explained_Simply.pdf")

FD = "/usr/share/fonts/truetype/dejavu"
pdfmetrics.registerFont(TTFont("DJ",  os.path.join(FD, "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DJB", os.path.join(FD, "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("DJI", os.path.join(FD, "DejaVuSans-Oblique.ttf")))
pdfmetrics.registerFont(TTFont("DJM", os.path.join(FD, "DejaVuSansMono.ttf")))

NAVY  = colors.HexColor("#0F1B2D")
BLUE  = colors.HexColor("#1E6FE0")
BLUEDK= colors.HexColor("#14539A")
GREEN = colors.HexColor("#1F9D57")
GREYBG = colors.HexColor("#F2F4F7")
BLUEBG = colors.HexColor("#EAF2FD")
GREYLN = colors.HexColor("#D6DBE2")
TEXT  = colors.HexColor("#1A2230")
MUTED = colors.HexColor("#5A6472")
WHITE = colors.white

ss = getSampleStyleSheet()
body = ParagraphStyle("body", parent=ss["Normal"], fontName="DJ", fontSize=10.3, leading=15.2, textColor=TEXT, spaceAfter=7, alignment=TA_LEFT)
h    = ParagraphStyle("h", fontName="DJB", fontSize=12.5, leading=16, textColor=NAVY, spaceBefore=10, spaceAfter=4)
liststyle = ParagraphStyle("list", parent=body, spaceAfter=4, leading=14.6)
small= ParagraphStyle("small", fontName="DJ", fontSize=8.6, leading=12, textColor=MUTED)
refh = ParagraphStyle("refh", fontName="DJB", fontSize=9.4, leading=13, textColor=BLUEDK, spaceBefore=6, spaceAfter=3)
ref  = ParagraphStyle("ref", fontName="DJ", fontSize=8.7, leading=12.4, textColor=TEXT, spaceAfter=4, leftIndent=12, firstLineIndent=-12)

def P(t, st=body): return Paragraph(t, st)
def bullets(items, st=liststyle):
    return ListFlowable([ListItem(Paragraph(t, st), leftIndent=12, value="•") for t in items],
                        bulletType="bullet", start="•", leftIndent=12, bulletFontName="DJ", bulletFontSize=9)

def box(title, text, accent=BLUE, bg=GREYBG):
    inner = []
    if title:
        inner.append(Paragraph("<b>%s</b>" % title, ParagraphStyle("bt", fontName="DJB", fontSize=10.3, leading=14, textColor=accent, spaceAfter=3)))
    if isinstance(text, list):
        inner += text
    else:
        inner.append(Paragraph(text, ParagraphStyle("bb", fontName="DJ", fontSize=10.1, leading=14.6, textColor=TEXT)))
    t = Table([[inner]], colWidths=[170*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), bg),
        ("LINEBEFORE",(0,0),(0,-1), 3.5, accent),
        ("LEFTPADDING",(0,0),(-1,-1),11),("RIGHTPADDING",(0,0),(-1,-1),11),
        ("TOPPADDING",(0,0),(-1,-1),9),("BOTTOMPADDING",(0,0),(-1,-1),9),
    ]))
    return t

def C(n):  # inline citation
    return "<super><font size=7 color='#14539A'>[%s]</font></super>" % n

def on_page(canvas, doc):
    canvas.saveState()
    w,hh = A4
    canvas.setStrokeColor(GREYLN); canvas.setLineWidth(0.5)
    canvas.line(18*mm, 12*mm, w-18*mm, 12*mm)
    canvas.setFont("DJ", 7.4); canvas.setFillColor(MUTED)
    canvas.drawString(18*mm, 8.4*mm, "HPET, TSC & the 'More FPS' question — what we tested and showed")
    canvas.drawRightString(w-18*mm, 8.4*mm, "Alchemy Tweaks  ·  p. %d" % doc.page)
    canvas.restoreState()

story = []

band = Table([[Paragraph("A PLAIN-ENGLISH COMPANION TO THE VIDEO", ParagraphStyle("bx", fontName="DJB", fontSize=9, textColor=colors.HexColor("#8Fc0FF"), leading=12))],
             [Paragraph("HPET, TSC &amp; the &ldquo;More FPS&rdquo; Question — What We Tested and Showed", ParagraphStyle("bt2", fontName="DJB", fontSize=16.5, textColor=WHITE, leading=20, spaceBefore=3))]],
            colWidths=[170*mm])
band.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),NAVY),
    ("LEFTPADDING",(0,0),(-1,-1),13),("RIGHTPADDING",(0,0),(-1,-1),13),
    ("TOPPADDING",(0,0),(0,0),11),("BOTTOMPADDING",(0,-1),(-1,-1),11),("TOPPADDING",(0,1),(-1,-1),0)]))
story.append(band)
story.append(Spacer(1,9))

story.append(box("WHAT THIS COMPANION IS (AND ISN'T)",
    "The only goal here is that you understand, in full, what we tested in the video, why, and exactly what you saw on screen. "
    "<b>It does not tell you what to do.</b> It explains what the setting is, states what Microsoft documents about it, and describes what our "
    "measurements showed — with every fact sourced at the end. Only two things are given as an opinion: what Microsoft recommends, and my own "
    "position, which is simply that you should measure it yourself.", BLUE, BLUEBG))
story.append(Spacer(1,4))

story.append(P("1. The background story — where this comes from", h))
story.append(P("For years, &ldquo;FPS boost&rdquo; guides, forum threads and optimizer scripts have told people to force a timer called <b>HPET</b> — "
    "by enabling it in the BIOS, or by running a command such as <font name='DJM'>bcdedit /set useplatformclock yes</font> — promising more FPS and "
    "lower input lag. The claim is everywhere, but it is rarely tested properly. This video tests it, end to end, and shows the raw measurements."))

story.append(P("2. The words you need (in plain English)", h))
story.append(P("Games ask Windows for the time constantly, through a function called <b>QueryPerformanceCounter (QPC)</b>. "+C(1)+" By default, Windows "
    "answers using the <b>TSC</b> — a counter built inside your CPU that is very fast to read. "+C(1)+" <b>HPET</b> and the <b>PM timer</b> are older "
    "clocks that sit outside the CPU, on the motherboard; Windows can use them, but reading them takes longer. "+C(1)+" The setting "
    "<font name='DJM'>useplatformclock</font> forces Windows to stop using the built-in TSC and use one of the outside clocks instead. "+C(2)))
story.append(P("A simple picture: the built-in clock is a <b>watch on your wrist</b> — you just glance at it. HPET is a <b>clock in another room</b> — "
    "every time you need the time, you walk over to check. Same time, a lot more effort."))

story.append(P("3. What exactly we test in the video", h))
story.append(P("We compare a few states, restart the PC between each so the change actually takes effect, and measure every one:"))
story.append(bullets([
    "<b>Default</b> — Windows' own automatic choice (what most PCs already run).",
    "<b>Platform clock forced</b> — <font name='DJM'>useplatformclock yes</font> (the claim under test).",
    "<b>Two settings people bundle with it</b> — <font name='DJM'>disabledynamictick</font> and <font name='DJM'>useplatformtick</font>.",
    "We return to <b>Default</b> between every state, so any difference we see is real and not just drift or a hot/busy moment.",
]))

story.append(P("4. What we measure — and why (this is the part that gives you the full picture)", h))
story.append(P("The headline measurement is direct and simple: <b>how long the clock takes to read</b>. We call QueryPerformanceCounter millions of "
    "times and count how many reads happen per second — on one core and across all cores. This is the fairest test because reading the clock is the "
    "exact thing <font name='DJM'>useplatformclock</font> changes; measuring it head-on is the cleanest evidence and far less noisy than FPS. "+C(1)))
story.append(P("Then we look at the practical side: interrupt/DPC latency, frametimes, 1% lows, and average FPS in a repeatable scene. FPS comes "
    "<i>last</i> on purpose — it is the noisiest signal, so it is there to show real-world impact, not to prove the mechanism."))

story.append(P("5. What Microsoft documents (facts, each one sourced)", h))
story.append(bullets([
    "Windows selects the timer source <b>automatically</b>: the TSC when it is suitable, otherwise HPET or the PM timer. "+C(1),
    "Reading the TSC costs about <b>10s to a few hundred CPU cycles</b>, and usually needs no trip into the kernel. Reading a platform timer "
    "(HPET/PM) is &ldquo;<b>frequently in the vicinity of 0.8&nbsp;–&nbsp;1.0 microseconds</b>&rdquo; and requires a system call. "+C(1),
    "Microsoft lists <font name='DJM'>useplatformclock</font>, <font name='DJM'>useplatformtick</font>, <font name='DJM'>disabledynamictick</font> "
    "and <font name='DJM'>tscsyncpolicy</font> as options that &ldquo;<b>should only be used for debugging</b>.&rdquo; "+C(2),
    "Independent measurements point the same way: Red Hat's timing test of 10&nbsp;million reads recorded roughly <b>0.6&nbsp;s on the TSC, ~12&nbsp;s "
    "on HPET and ~24&nbsp;s on the PM timer</b>; "+C(3)+" VMware documents an HPET read at about <b>1&nbsp;–&nbsp;2 microseconds</b>. "+C(4),
]))

story.append(P("6. What Microsoft recommends", h))
story.append(P("Microsoft's documentation treats the automatic selection as the normal behaviour and labels these settings as <b>debugging tools, not "
    "performance settings</b>. "+C(1)+C(2)+" In other words, Microsoft does not present forcing the platform clock as a way to gain FPS. That is "
    "Microsoft's stated position, and we pass it on exactly as written — nothing added."))

story.append(box("7. MY POSITION — THE ONLY THING I'LL ASK OF YOU",
    "I am not going to tell you to change anything, or to undo anything. My one and only recommendation is this: <b>don't take my word for it — or "
    "anyone else's. Run the same measurement on your own PC and let your own numbers decide.</b> The tools I used are included so you can repeat it "
    "exactly.", GREEN, colors.HexColor("#EAF7EF")))
story.append(Spacer(1,4))

story.append(P("8. Does this apply to Windows 10 and Windows 11?", h))
story.append(P("Yes — for this topic the timer design is the same on both (it has not changed since Windows&nbsp;8), and the settings exist on both. "
    +C(1)+C(2)+" One thing that <i>is</i> different between Windows&nbsp;10 and&nbsp;11 — &ldquo;timer resolution&rdquo; — is a separate subject and "
    "does not change these clock-reading results. "+C(5)))

story.append(P("A note on a related setting: tscsyncpolicy", h))
story.append(P("You may also hear claims about a related boot setting, <font name='DJM'>tscsyncpolicy</font> (Default / Legacy / Enhanced). To be "
    "precise and neutral: Microsoft documents it as the &ldquo;time stamp counter synchronization policy&rdquo; and says it &ldquo;should only be used "
    "for debugging.&rdquo; "+C(2)+" It concerns how Windows lines up the CPU's clock <b>at startup</b> — a boot-time matter, not a per-frame one. "
    "Independent reverse-engineering found the setting does reach the kernel, and that &ldquo;default&rdquo; and simply leaving it unset are the same. "+C(7)+" "
    "Claims that it &ldquo;does nothing on Windows&nbsp;10&rdquo; or &ldquo;no longer works on Windows&nbsp;11&rdquo; are <b>not confirmed by any official "
    "source</b> — the current documentation still lists it. We do not assert those claims either way; if it matters to you, measure it."))
story.append(HRFlowable(width="100%", thickness=1.0, color=GREYLN, spaceBefore=8, spaceAfter=5))
story.append(P("References &amp; bibliography", h))
story.append(Paragraph("Official (primary) sources", refh))
story.append(Paragraph("[1] Microsoft Learn — <i>Acquiring high-resolution time stamps</i> (QPC, TSC, HPET and PM timer; read costs; automatic "
    "selection). learn.microsoft.com/en-us/windows/win32/sysinfo/acquiring-high-resolution-time-stamps", ref))
story.append(Paragraph("[2] Microsoft Learn — <i>BCDEdit /set</i> (boot options: useplatformclock, useplatformtick, disabledynamictick, tscsyncpolicy; "
    "&ldquo;debugging only&rdquo;). learn.microsoft.com/en-us/windows-hardware/drivers/devtest/bcdedit--set", ref))
story.append(Paragraph("[5] Microsoft Learn — <i>timeBeginPeriod</i> (timer resolution; Windows 10 / 11 behaviour; note that it does not affect QPC). "
    "learn.microsoft.com/en-us/windows/win32/api/timeapi/nf-timeapi-timebeginperiod", ref))
story.append(Paragraph("[6] Intel — <i>IA-PC HPET (High Precision Event Timers) Specification 1.0a</i> (what HPET is; discovered via ACPI). "
    "intel.com — software-developers-hpet-spec-1-0a.pdf", ref))
story.append(Paragraph("Independent corroboration (secondary) sources", refh))
story.append(Paragraph("[3] Red Hat — <i>RHEL for Real Time: hardware clocks &amp; timestamping</i> (measured read times: TSC vs HPET vs ACPI_PM). "
    "docs.redhat.com", ref))
story.append(Paragraph("[4] VMware — <i>Timekeeping in VMware Virtual Machines</i> (HPET read latency ~1–2 µs; timer characteristics). "
    "vmware.com/docs/vmware_timekeeping", ref))
story.append(Paragraph("[7] valleyofdoom/PC-Tuning — <i>research.md</i> (kernel-debugger analysis: tscsyncpolicy maps to HalpTscSyncPolicy; &ldquo;default&rdquo; equals unset). github.com/valleyofdoom/PC-Tuning", ref))
story.append(Spacer(1,5))
story.append(P("Neutral by design: every fact above is cited; the only opinions are Microsoft's stated position (Sections 5–6) and mine (Section 7 — "
    "measure it yourself).", small))

doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=15*mm, bottomMargin=16*mm,
                        title="HPET, TSC & the 'More FPS' Question — What We Tested and Showed", author="Alchemy Tweaks")
doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
print("WROTE", OUT, os.path.getsize(OUT), "bytes")
