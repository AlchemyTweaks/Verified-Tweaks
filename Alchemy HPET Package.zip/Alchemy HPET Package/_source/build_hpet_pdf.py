# -*- coding: utf-8 -*-
"""
Builds: Alchemy_HPET_Master_Package_v2.pdf
A complete, source-verified production & verification package for the HPET /
useplatformclock debunk video. English. reportlab Platypus.
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Preformatted, KeepTogether, HRFlowable, PageBreak, ListFlowable, ListItem)
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Alchemy_HPET_Master_Package.pdf")

# ---------- fonts ----------
FD = "/usr/share/fonts/truetype/dejavu"
pdfmetrics.registerFont(TTFont("DJ",  os.path.join(FD, "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DJB", os.path.join(FD, "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("DJI", os.path.join(FD, "DejaVuSans-Oblique.ttf")))
pdfmetrics.registerFont(TTFont("DJM", os.path.join(FD, "DejaVuSansMono.ttf")))
pdfmetrics.registerFont(TTFont("DJMB", os.path.join(FD, "DejaVuSansMono-Bold.ttf")))

# ---------- palette ----------
NAVY   = colors.HexColor("#0F1B2D")
NAVY2  = colors.HexColor("#17293F")
BLUE   = colors.HexColor("#1E6FE0")
BLUEDK = colors.HexColor("#14539A")
RED    = colors.HexColor("#D23B3B")
GREEN  = colors.HexColor("#1F9D57")
AMBER  = colors.HexColor("#B7791F")
GREYBG = colors.HexColor("#F2F4F7")
CODEBG = colors.HexColor("#111A28")
GREYLN = colors.HexColor("#D6DBE2")
TEXT   = colors.HexColor("#1A2230")
MUTED  = colors.HexColor("#5A6472")
WHITE  = colors.white

# ---------- styles ----------
ss = getSampleStyleSheet()
def S(name, **kw):
    base = kw.pop("parent", ss["Normal"])
    return ParagraphStyle(name, parent=base, **kw)

body   = S("body", fontName="DJ", fontSize=9.3, leading=13.6, textColor=TEXT, alignment=TA_JUSTIFY, spaceAfter=6)
bodyL  = S("bodyL", parent=body, alignment=TA_LEFT)
lead   = S("lead", fontName="DJ", fontSize=10, leading=15, textColor=TEXT, alignment=TA_LEFT, spaceAfter=7)
h1     = S("h1", fontName="DJB", fontSize=15, leading=18, textColor=NAVY, spaceBefore=6, spaceAfter=8)
h2     = S("h2", fontName="DJB", fontSize=11.5, leading=15, textColor=BLUEDK, spaceBefore=10, spaceAfter=5)
h3     = S("h3", fontName="DJB", fontSize=9.8, leading=13, textColor=NAVY, spaceBefore=7, spaceAfter=3)
small  = S("small", fontName="DJ", fontSize=8.1, leading=11, textColor=MUTED)
smallC = S("smallC", parent=small, alignment=TA_CENTER)
tiny   = S("tiny", fontName="DJ", fontSize=7.4, leading=9.6, textColor=MUTED)
list   = S("list", parent=bodyL, spaceAfter=3, leading=13.2)
codest = S("code", fontName="DJM", fontSize=8.0, leading=11.2, textColor=colors.HexColor("#E8EEF6"),
           backColor=CODEBG, borderPadding=(7,7,7,7), leftIndent=2, spaceBefore=3, spaceAfter=7)
kbd    = S("kbd", fontName="DJM", fontSize=8.4, textColor=NAVY)
th     = S("th", fontName="DJB", fontSize=8.4, leading=11, textColor=WHITE)
td     = S("td", fontName="DJ", fontSize=8.3, leading=11.4, textColor=TEXT)
tdb    = S("tdb", parent=td, fontName="DJB")
tdc    = S("tdc", parent=td, fontName="DJM", fontSize=7.8)
tdw    = S("tdw", parent=td, textColor=WHITE)

def cell(txt, st=td):  return Paragraph(txt, st)

def code(txt):
    return Preformatted(txt, codest)

def rule(c=GREYLN, w=0.8, sb=2, sa=6):
    return HRFlowable(width="100%", thickness=w, color=c, spaceBefore=sb, spaceAfter=sa)

def bullets(items, st=list, bullet="•"):
    return ListFlowable(
        [ListItem(Paragraph(t, st), leftIndent=12, value=bullet) for t in items],
        bulletType="bullet", start=bullet, leftIndent=10, bulletFontName="DJ", bulletFontSize=8)

def callout(title, text, accent=BLUE, bg=GREYBG, tcol=None):
    tcol = tcol or accent
    inner = []
    if title:
        inner.append(Paragraph('<b>%s</b>' % title, S("cotitle", fontName="DJB", fontSize=9, leading=12.5, textColor=tcol, spaceAfter=2)))
    inner.append(Paragraph(text, S("cobody", fontName="DJ", fontSize=8.7, leading=12.4, textColor=TEXT)))
    t = Table([[inner]], colWidths=[165*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), bg),
        ("LINEBEFORE",(0,0),(0,-1), 3, accent),
        ("LEFTPADDING",(0,0),(-1,-1), 9), ("RIGHTPADDING",(0,0),(-1,-1), 9),
        ("TOPPADDING",(0,0),(-1,-1), 7), ("BOTTOMPADDING",(0,0),(-1,-1), 7),
    ]))
    return t

def tier_badge(t):
    cmap = {"T1":GREEN, "T2":colors.HexColor("#2E8B57"), "T3":BLUE, "T4":AMBER, "T5":RED}
    return '<font name="DJB" color="%s">%s</font>' % (cmap.get(t, MUTED).hexval(), t)

def table(data, colWidths, header=True, zebra=True, fs=8.3, align=None):
    t = Table(data, colWidths=colWidths, repeatRows=1 if header else 0)
    stylecmds = [
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("LEFTPADDING",(0,0),(-1,-1),5), ("RIGHTPADDING",(0,0),(-1,-1),5),
        ("TOPPADDING",(0,0),(-1,-1),4), ("BOTTOMPADDING",(0,0),(-1,-1),4),
        ("LINEBELOW",(0,0),(-1,-1),0.4, GREYLN),
        ("LINEBEFORE",(0,0),(-1,-1),0.3, GREYLN),
        ("LINEAFTER",(0,0),(-1,-1),0.3, GREYLN),
    ]
    if header:
        stylecmds += [("BACKGROUND",(0,0),(-1,0), NAVY), ("LINEBELOW",(0,0),(-1,0),0.6, NAVY)]
    if zebra:
        for r in range(1, len(data)):
            if r % 2 == 0:
                stylecmds.append(("BACKGROUND",(0,r),(-1,r), colors.HexColor("#F7F9FC")))
    if align:
        for (c0,c1,a) in align:
            stylecmds.append(("ALIGN",(c0,0),(c1,-1),a))
    t.setStyle(TableStyle(stylecmds))
    return t

# ---------- page furniture ----------
def on_page(canvas, doc):
    canvas.saveState()
    w, h = A4
    # footer rule
    canvas.setStrokeColor(GREYLN); canvas.setLineWidth(0.5)
    canvas.line(18*mm, 12*mm, w-18*mm, 12*mm)
    canvas.setFont("DJ", 7.2); canvas.setFillColor(MUTED)
    canvas.drawString(18*mm, 8.4*mm, "ALCHEMY · HPET Debunk - Master Verification & Production Package v2.0")
    canvas.drawRightString(w-18*mm, 8.4*mm, "p. %d" % doc.page)
    canvas.setFont("DJ", 7.2); canvas.setFillColor(colors.HexColor("#9AA3AF"))
    canvas.drawRightString(w-18*mm, h-9*mm, "Source-verified · measured, not assumed")
    canvas.restoreState()

story = []

# ================= COVER BAND =================
def band():
    tt = Table([[Paragraph('ALCHEMY&nbsp;&nbsp;·&nbsp;&nbsp;WINDOWS PERFORMANCE OPTIMIZATION',
                 S("bx", fontName="DJB", fontSize=8.6, textColor=colors.HexColor("#8Fc0FF"), leading=11))],
                [Paragraph('HPET Debunk - Master Package', S("bt", fontName="DJB", fontSize=21, textColor=WHITE, leading=24, spaceBefore=3))],
                [Paragraph('“useplatformclock true for FPS” - verified, measured, and production-ready',
                 S("bs", fontName="DJ", fontSize=10, textColor=colors.HexColor("#C9D6E8"), leading=14, spaceBefore=3))],
                [Paragraph('v2.0 · supersedes v1 (02 Jul 2026) · rebuilt against Microsoft Learn + independent corroboration · 03 Jul 2026',
                 S("bd", fontName="DJ", fontSize=7.8, textColor=colors.HexColor("#8996A8"), leading=11, spaceBefore=6))]],
               colWidths=[177*mm])
    tt.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), NAVY),
        ("LEFTPADDING",(0,0),(-1,-1),14),("RIGHTPADDING",(0,0),(-1,-1),14),
        ("TOPPADDING",(0,0),(0,0),12),("BOTTOMPADDING",(0,-1),(-1,-1),12),
        ("TOPPADDING",(0,1),(-1,-1),0),
    ]))
    return tt
story.append(band())
story.append(Spacer(1,10))

story.append(callout("WHAT THIS DOCUMENT IS",
    "A single, self-contained package to make the HPET video flawless: (1) an honest audit of the v1 PDF and your research notes, "
    "(2) a thumbnail integrity review with a corrected version, (3) the fully source-verified mechanism, (4) exactly what to test, "
    "how to test it, and how to read the results without overclaiming, (5) a tightened word-for-word script, and (6) two ready-to-run tools. "
    "Every technical claim carries an evidence tier and, where it matters, a verbatim source quote.", BLUE))
story.append(Spacer(1,6))

# evidence tier legend
story.append(Paragraph("Evidence tiers used throughout", h3))
leg = [[cell("Tier", th), cell("Meaning", th)],
       [cell(tier_badge("T1"), tdb), cell("Official vendor / standards documentation (Microsoft Learn, Intel/AMD spec).", td)],
       [cell(tier_badge("T2"), tdb), cell("Rigorously measured / peer-reviewed data with a stated method (e.g. vendor benchmark).", td)],
       [cell(tier_badge("T3"), tdb), cell("Reputable secondary technical analysis; sound engineering inference from T1 facts.", td)],
       [cell(tier_badge("T4"), tdb), cell("Anecdotal / community claim (forum, video, marketing) - directional only, never stated as fact.", td)],
       [cell(tier_badge("T5"), tdb), cell("Unverified / no source located - flagged, never used as support.", td)]]
story.append(table(leg, [18*mm, 159*mm]))
story.append(Spacer(1,4))
story.append(Paragraph("Integrity rule for the whole video: the expected verdict is that forcing the platform clock is harmful-or-pointless, "
    "but the verdict is <b>produced by your measurement on camera</b>, not assumed in advance. If your data disagrees with the expectation, "
    "the data wins and the script bends to it.", bodyL))

story.append(PageBreak())

# ================= 1. EXECUTIVE SUMMARY =================
story.append(Paragraph("1 · Executive summary - the corrected thesis", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("The one line", h3))
story.append(callout(None,
    "“Forcing the platform clock with <font name='DJM'>useplatformclock yes</font> does not add FPS. It replaces a fast, in-CPU timer "
    "(the invariant TSC) with a slower, shared, off-chip timer (HPET/PM) that Windows itself only falls back to when the TSC is broken. "
    "The read cost is <b>higher</b> and - on Microsoft's own numbers - a platform-timer read even requires a kernel transition. "
    "It is a Microsoft-documented <b>debugging</b> switch, not a gaming optimisation.”", NAVY, GREYBG, NAVY))
story.append(Spacer(1,4))
story.append(Paragraph("Why v1 needed a rebuild", h3))
story.append(Paragraph("The v1 package was directionally correct and had the right instinct (measure the timer-read cost before FPS). "
    "But for a channel that sells <i>measured, transparent, no cherry-picking</i>, it carried several claims that were too strong, "
    "one detection shortcut that Microsoft explicitly warns against, and it collapsed three different “HPET” switches into one. "
    "This v2 fixes all of that and adds independent corroboration (Red Hat, VMware, Intel) so the strongest claim - higher read cost - "
    "now rests on four converging sources, not one.", bodyL))
story.append(Paragraph("What is provable vs what must be measured", h3))
prov = [[cell("Claim", th), cell("Status going in", th), cell("Backed by", th)],
        [cell("Forcing HPET/PM raises the QPC timer-read cost", tdb), cell("<b>Provable / near-certain</b>", td), cell("T1 Microsoft + T2 Red Hat + T3 VMware + Intel spec", td)],
        [cell("Platform-timer QPC needs a kernel transition (syscall)", tdb), cell("<b>Documented fact</b>", td), cell("T1 Microsoft Learn (QPC FAQ)", td)],
        [cell("DPC/ISR latency gets worse under forced HPET", tdb), cell("Plausible - <b>must measure</b>", td), cell("mechanism only; system-dependent", td)],
        [cell("1% lows / frametime get worse under forced HPET", tdb), cell("<b>Must measure</b>; often within noise", td), cell("no universal evidence; varies by title & rig", td)],
        [cell("Default on a modern gaming PC is TSC", tdb), cell("True for the target audience", td), cell("T1 (auto-select), with caveats", td)]]
story.append(table(prov, [58*mm, 47*mm, 72*mm]))
story.append(Spacer(1,6))
story.append(Paragraph("1.1 · OS scope - this package covers Windows 10 and Windows 11", h2))
story.append(Paragraph("Everything here applies to <b>both Windows 10 and Windows 11 (x64)</b>. QPC/TSC/HPET selection is the same "
    "Windows-8-onward architecture - Microsoft documents it by version through Windows 8/8.1 and defines no separate Windows 10 vs 11 behaviour for "
    "x64 (only Arm devices differ). All four bcdedit knobs exist on both OSes (<font name='DJM'>useplatformtick</font> and "
    "<font name='DJM'>tscsyncpolicy</font> since Windows 8). So the mechanism, the commands, and the whole test protocol are identical on 10 and 11. " + tier_badge("T1"), bodyL))
story.append(callout("THE ONE REAL WIN10 vs WIN11 DIFFERENCE (and why it does not affect this video)",
    "It is <b>timer resolution</b>, not QPC. Microsoft: since <b>Windows 10 v2004</b>, <font name='DJM'>timeBeginPeriod</font> is <b>per-process</b>, "
    "not global; and <b>Windows 11</b> adds that a fully occluded/minimised window-owning process is not guaranteed a higher resolution. Crucially, "
    "the same docs state: &ldquo;<b>Setting a higher resolution does not improve the accuracy of the high-resolution performance counter.</b>&rdquo; So "
    "timer resolution is a <b>separate topic</b> (your next video) and does <b>not</b> change the HPET/QPC results here. It only affects how you frame "
    "the <font name='DJM'>disabledynamictick</font> state - capture it on each OS and do not generalise a dynamic-tick result across both. " + tier_badge("T1"), BLUE))
story.append(Paragraph("Practical rule: record the exact edition + build with every result (e.g. Windows 10 22H2 build 19045, Windows 11 23H2 / 24H2 / "
    "25H2) and re-verify against the build you actually publish on - Windows can tune internal behaviour between builds.", bodyL))

story.append(Spacer(1,6))
story.append(Paragraph("1.2 · Full transparency - what &ldquo;myth&rdquo; means here, and how every claim is labelled", h2))
story.append(Paragraph("So the video survives a hostile, technical audience, this package follows one hard rule: <b>nothing is presented as fact unless it "
    "is documented (T1-T3)</b>. Everything else is either attributed to others with a neutral stance, or produced by your own measurement on camera.", bodyL))
story.append(Paragraph("Terminology, stated plainly:", h3))
story.append(bullets([
    "<b>&ldquo;Myth&rdquo;</b> = a widely-shared claim that forcing these timer settings improves gaming (more FPS / less input lag). It is the claim "
    "we <i>test</i> - not something we assume is false. We only call it a myth <i>after</i> measurement, if the data shows no benefit.",
    "<b>&ldquo;Debunk&rdquo;</b> = show the documented mechanism, then measure, then let the numbers decide. It does not mean declaring a result in advance.",
]))
story.append(Paragraph("How every claim in this document (and the video) is labelled:", h3))
lbl = [[cell("Label", th), cell("Meaning", th), cell("May we assert it?", th)],
       [cell("DOCUMENTED FACT", tdb), cell("Stated by Microsoft / Intel / Red Hat / VMware; quoted or cited (T1-T2).", td), cell("Yes - with the source shown.", td)],
       [cell("REASONED INFERENCE", tdb), cell("Our engineering conclusion drawn from documented facts (T3), labelled as inference.", td), cell("Yes, as OUR reasoning - confirmed by measurement.", td)],
       [cell("COMMUNITY CLAIM", tdb), cell("What others say without documentation (T4).", td), cell("No - attribute it, stay neutral, leave it to the audience or the test.", td)],
       [cell("MEASURED RESULT", tdb), cell("Produced by your runs on camera.", td), cell("Yes - the only thing that turns a claim into a verdict.", td)]]
story.append(table(lbl, [40*mm, 90*mm, 47*mm]))
story.append(callout("THE NEUTRAL-STANCE RULE (applied throughout)",
    "Where a claim cannot be documented, we do three things and no more: (1) say <b>who</b> claims it, (2) say we <b>could not verify</b> it, and "
    "(3) leave it to the audience or to the measurement. We never repeat it as fact, and we never mock it. You can see this rule applied in the "
    "tscsyncpolicy section (8.1), the community cross-check (17.2), and the source pack (15), where every load-bearing claim carries a tier.", BLUE))

# ================= 2. V1 AUDIT =================
story.append(Paragraph("2 · Audit of the v1 PDF - where it was incomplete", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("v1 was a solid script outline. The gaps below are the difference between “a good video” and one that survives a "
    "sceptical, technical audience.", bodyL))
story.append(bullets([
    "<b>QPF used as a source detector.</b> v1 said “~14.318&nbsp;MHz = HPET; different value = TSC/other.” Microsoft explicitly states "
    "QueryPerformanceFrequency is often <b>fixed to 10&nbsp;MHz</b> on modern Windows and “don't assume [it] will return a value derived from "
    "the hardware frequency.” So QPF is an <i>indicator</i>, not proof. " + tier_badge("T1"),
    "<b>“Running your PC in debug mode.”</b> Catchy but misleading - a single BCD flag is not the same as a debug-checked build. It reads as "
    "clickbait to informed viewers. Cut it (see §13).",
    "<b>“useplatformclock false ≈ default.”</b> The documented way back to default is <font name='DJM'>/deletevalue</font>, which removes the "
    "override entirely. An explicit <font name='DJM'>false</font> is a set value, not the clean baseline. " + tier_badge("T1"),
    "<b>Three “HPET” layers were merged.</b> BIOS HPET, the Device Manager device, and the BCD flag are different things with different "
    "effects (see §6). v1's hook said “enable HPET - force the platform clock” as if identical.",
    "<b>Certainty the data hasn't earned yet.</b> v1 leaned toward “worse” for DPC and frametime before measuring. Correct instinct, but the "
    "wording must stay conditional until your runs land.",
    "<b>Thin statistics.</b> 3-5 runs, A/B/A/B was fine but with no median-vs-mean rule, no CoV, no percentile frametimes, no reboot-verification "
    "step. Added in §12.",
    "<b>Single-source citations.</b> The strongest claim (read cost) leaned on one Microsoft page. It is now cross-checked against three "
    "independent sources.",
]))

# ================= 3. MD AUDIT =================
story.append(Paragraph("3 · Audit of your research notes (.md) - strong, with two refinements", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("Your <font name='DJM'>Agent_Verification_Guide.md</font> is a serious upgrade and closes almost every v1 gap. It is the "
    "backbone of this v2. What it got right, and the two things to sharpen:", bodyL))
story.append(Paragraph("What your notes fixed (kept in full)", h3))
story.append(bullets([
    "The strict wording rules and the explicit “avoid” list - including the two traps above.",
    "“Clean default = <font name='DJM'>deletevalue</font>, not <font name='DJM'>false</font>.” Correct and now T1-sourced.",
    "The A→B→A→C→A… order to detect drift and prove reversibility.",
    "Primary proof = QPC read cost, before FPS; median-first statistics; four-way verdict framework.",
    "Per-state reboot verification and metadata capture.",
]))
story.append(Paragraph("Two refinements this v2 adds on top", h3))
story.append(bullets([
    "<b>Give the QPF decode table <i>with</i> the caveat</b> (your notes rightly say QPF isn't proof, but a viewer still needs the numbers). "
    "§7 provides the decode plus the “not fixed for HPET” nuance (HPET can read 14.318 / 15 / ~18 / 24&nbsp;MHz depending on chipset).",
    "<b>Name the Device-Manager placebo explicitly.</b> Your matrix lists “Device Manager HPET” as optional/appendix; §6 upgrades it to a "
    "teachable correction because it is one of the most repeated wrong tweaks - and, as you noted, it does not disable HPET.",
]))

# ================= 4. THUMBNAIL =================
story.append(PageBreak())
story.append(Paragraph("4 · Thumbnail review - is it appropriate or misleading?", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("Verdict: <b>directionally correct, but it overclaims on two of its three regression bullets</b>, and the way it is framed can "
    "contradict your own on-camera data. For a “no cherry-picking” brand that is a real risk. Here is the claim-by-claim read.", bodyL))
tb = [[cell("Thumbnail claim (HPET FORCED side)", th), cell("Verdict", th), cell("Why", th)],
      [cell("Higher Overhead", tdb), cell("<font color='%s'><b>KEEP - provable</b></font>" % GREEN.hexval(), td),
       cell("The timer-read cost genuinely rises; four converging sources. This is your strongest, most defensible bullet.", td)],
      [cell("More DPC Latency", tdb), cell("<font color='%s'><b>SOFTEN - conditional</b></font>" % AMBER.hexval(), td),
       cell("Plausible and mechanism-supported, but not guaranteed; it is system-dependent and must be measured. Presenting it as a certainty is an overclaim.", td)],
      [cell("Worse 1% Lows", tdb), cell("<font color='%s'><b>RISKY - often noise</b></font>" % RED.hexval(), td),
       cell("On many modern rigs, forced HPET moves 1% lows by less than run-to-run variance. If your data shows no change, the thumbnail contradicts the video.", td)],
      [cell("DEFAULT (TSC) label", tdb), cell("<font color='%s'><b>OK with caveat</b></font>" % BLUE.hexval(), td),
       cell("True for a modern gaming PC, but “default” really means Windows auto-selects; it is not <i>always</i> TSC. Fine on the thumbnail if the video adds the nuance.", td)]]
story.append(table(tb, [46*mm, 40*mm, 91*mm]))
story.append(Spacer(1,5))
story.append(callout("IS IT MISLEADING?",
    "Not dishonest - the direction (default ≥ forced HPET) is right. But it asserts <b>three guaranteed regressions before any data is shown</b>, "
    "and two of them (DPC latency, 1% lows) may not reproduce on your rig. That is the exact failure mode your brand promises to avoid. "
    "Recommendation: anchor the thumbnail on the one thing you can always prove, and make the softer claims conditional or drop them.", AMBER))
story.append(Paragraph("Corrected, defensible thumbnail spec", h3))
story.append(bullets([
    "<b>Headline stays:</b> HPET · MYTH. TESTED. MEASURED. (this is great).",
    "<b>Left panel (HPET FORCED) - replace the three bullets with:</b> “Slower timer reads” (KEEP), “Needs a kernel call” (KEEP - it is a "
    "documented fact and sounds technical/credible), and “No FPS benefit” (this is the actual payload of the video).",
    "<b>Right panel (DEFAULT / TSC):</b> “Fast in-CPU reads”, “User-mode, no syscall”, “What Windows already picks”.",
    "<b>Optionally keep one number instead of a vague arrow:</b> e.g. “~1&nbsp;µs vs ~tens of ns per read” - that single, sourced contrast is more "
    "persuasive and safer than three unproven ‘worse’ arrows.",
    "<b>If you want to keep ‘1% lows’ visually,</b> phrase it as a question (“Better 1% lows?”) so the video answers it with data instead of the "
    "thumbnail pre-committing to a result.",
]))
story.append(Paragraph("Net: the current thumbnail is usable but sits at the edge of your integrity line on DPC/1%-lows. The corrected version keeps "
    "all the punch while every bullet is something you can put a measured number behind.", bodyL))

# ================= 5. MECHANISM =================
story.append(PageBreak())
story.append(Paragraph("5 · The verified mechanism (QPC / TSC / HPET / PM)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("Games ask Windows for time through <b>QueryPerformanceCounter (QPC)</b>. What hardware answers that call is the whole story. "
    "Every fact below is quoted or paraphrased from Microsoft Learn, <i>Acquiring high-resolution time stamps</i>, and corroborated where noted.", bodyL))

story.append(Paragraph("5.1 · TSC - the fast path (what modern Windows uses by default)", h2))
story.append(bullets([
    "Per-CPU register, read with <font name='DJM'>RDTSC</font>. Microsoft: cost is “<b>10s of CPU cycles to several hundred</b>.” " + tier_badge("T1"),
    "On TSC, “<b>user-mode queries often bypass system calls</b>” and there is “<b>no added overhead for concurrent calls</b>.” " + tier_badge("T1"),
    "Windows auto-selects TSC when the processor has an <b>invariant TSC</b> and can synchronise it across cores at boot. " + tier_badge("T1"),
    "Invariant TSC is <b>unaffected</b> by Turbo/power-state frequency changes - so the common “TSC drifts under boost” fear is wrong for modern CPUs. " + tier_badge("T1"),
]))
story.append(Paragraph("5.2 · HPET / PM - the fallback (what useplatformclock forces)", h2))
story.append(bullets([
    "HPET is “a <b>shared, platform-wide resource</b>” with “<b>higher access latency than the TSC</b>” that “<b>limits scalability of QPC if it is "
    "called concurrently from multiple processors</b>.” " + tier_badge("T1"),
    "Microsoft puts a number on it: a platform-timer read is “<b>frequently in the vicinity of 0.8-1.0 microseconds</b> … dominated by the "
    "time required to access the hardware device on the motherboard.” " + tier_badge("T1"),
    "And the decisive extra cost: “<b>A kernel transition is not required if the system can use the TSC … If the system must use a different time "
    "base, such as the HPET or PM timer, a system call is required.</b>” " + tier_badge("T1"),
    "The PM (ACPI) timer provides a timestamp in one clock cycle but nothing else, at 3.579545&nbsp;MHz. " + tier_badge("T1"),
]))
story.append(callout("CONVERGING EVIDENCE FOR ‘HIGHER OVERHEAD’ (this is why it is your safest claim)",
    "Four independent sources agree the platform timer is far slower to read than the TSC:<br/>"
    "• <b>Microsoft</b> - TSC ≈ 10s-100s of cycles; HPET/PM ≈ 0.8-1.0&nbsp;µs + a syscall. " + tier_badge("T1") + "<br/>"
    "• <b>Red Hat MRG</b> - 10&nbsp;million reads: TSC ≈ 0.6&nbsp;s, HPET ≈ 12&nbsp;s, ACPI&nbsp;PM ≈ 24&nbsp;s (≈20× and ≈40× slower). " + tier_badge("T2") + "<br/>"
    "• <b>VMware</b> - “≈ 1-2&nbsp;µs to read the HPET”; spec “does not require the timer to be … fast to read.” " + tier_badge("T3") + "<br/>"
    "• <b>Intel IA-PC HPET spec</b> - HPET is MMIO, ACPI-discovered, min 10&nbsp;MHz; an off-chip southbridge/PCH device. " + tier_badge("T1"), GREEN))
story.append(Paragraph("5.3 · The honest ‘why it exists’ (keeps the video credible)", h2))
story.append(Paragraph("<font name='DJM'>useplatformclock</font> is a legitimate <b>compatibility/debugging</b> override for genuinely broken or "
    "non-invariant TSC platforms (some multi-node servers, flawed firmware, TSC-sync faults). Microsoft's own guidance is that you do not need to "
    "check or force any of this yourself: “Windows operating systems perform several checks at system initialization to determine if the TSC is "
    "suitable as a basis for QPC.” Forcing the platform clock overrides that validated decision - for no gaming benefit. " + tier_badge("T1"), bodyL))

# ================= 6. THREE SWITCHES + DEVICE MANAGER =================
story.append(PageBreak())
story.append(Paragraph("6 · The three “HPET switches” are not equal - and one is a placebo", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("This is the single most valuable teaching beat in the video, because even experienced tweak guides get it wrong. Only two of "
    "these three actually change what timer the kernel uses.", bodyL))
sw = [[cell("Layer", th), cell("What it really is", th), cell("Effect on the QPC timer source", th)],
      [cell("BIOS / UEFI: HPET on/off", tdb), cell("Firmware exposes (or hides) the HPET via the ACPI HPET table.", td),
       cell("<b>Real.</b> Removes/adds HPET as an option the OS can select or be forced onto. On a modern rig already on TSC it is usually moot.", td)],
      [cell("Device Manager: “High Precision Event Timer” (ACPI\\PNP0103)", tdb),
       cell("The PnP / ACPI namespace representation of the HPET device node.", td),
       cell("<b>Placebo for timing.</b> Disabling it removes the PnP device instance but does <b>not</b> stop the kernel/HAL from using HPET. See the evidence chain below.", td)],
      [cell("BCD: useplatformclock yes", tdb), cell("A boot flag read by the HAL at startup.", td),
       cell("<b>Real and the actual lever.</b> Forces QPC onto the platform clock (HPET/PM). This is what the myth is really about.", td)]]
story.append(table(sw, [40*mm, 55*mm, 82*mm]))
story.append(Spacer(1,5))
story.append(Paragraph("6.1 · Why disabling HPET in Device Manager does NOT disable HPET - the evidence chain", h2))
story.append(Paragraph("You asked for this to be nailed down with hard evidence and honest tiering. Here it is, separated into what is <b>directly "
    "documented</b> and what is a <b>sound conclusion</b> from it.", bodyL))
story.append(Paragraph("Directly documented facts", h3))
story.append(bullets([
    "The OS discovers and accesses HPET through the <b>ACPI HPET table</b> (a memory-mapped register block, base commonly <font name='DJM'>0xFED00000</font>), "
    "parsed at boot. " + tier_badge("T1") + " (Intel IA-PC HPET Specification; ACPI).",
    "Windows builds timer support on <b>standard ACPI tables at the HAL level</b>: “Windows builds in support for these features [timers, interrupt "
    "controllers] based on the standard tables described in ACPI.” " + tier_badge("T1") + " (Microsoft Learn, ACPI system description tables).",
    "For a system-board device, <font name='DJM'>Acpi.sys</font> creates an <b>ACPI bus filter above the PDO</b> - it provides PnP/power plumbing, it "
    "is not the timer's function driver. “All ACPI functionality is transparent to higher-level drivers.” " + tier_badge("T1"),
    "<font name='DJM'>PNP0103</font> is the ACPI hardware ID that Device Manager shows as “High Precision Event Timer” under <i>System devices</i> - a standard PnP-ID/registry fact, not a Microsoft-primary statement. " + tier_badge("T4"),
]))
story.append(Paragraph("The sound conclusion (corroborated, not a single verbatim MS sentence)", h3))
story.append(callout(None,
    "Because the HAL/kernel reaches HPET through the ACPI HPET <i>table</i> - independent of the PnP device node - disabling the “High Precision "
    "Event Timer” entry in Device Manager removes the user-facing PnP instance but <b>does not remove the kernel's table-based use of HPET</b>. "
    "The HPET has no separate function-driver binary to unload; its servicing is embedded in the kernel/HAL. Kernel-mode code can therefore still "
    "use HPET. This is a well-established internals conclusion corroborated by multiple independent expert sources; it is graded " + tier_badge("T3") +
    " (engineering inference from " + tier_badge("T1") + " architecture), <b>not</b> presented as a verbatim Microsoft statement, because no single "
    "Microsoft page states it in those words.", BLUE, GREYBG, BLUEDK))
story.append(Paragraph("What we deliberately do NOT claim", h3))
story.append(bullets([
    "We do not claim the Device Manager toggle has <i>zero</i> effect on anything (a user-mode app that enumerates the PnP device could notice). We "
    "claim only that it does not change the QPC/kernel timer source.",
    "The only fully-documented levers for the QPC source are <b>firmware (BIOS HPET)</b> and <b>BCD (useplatformclock)</b>. That is the line to hold "
    "on camera.",
]))
story.append(Paragraph("6.2 · “Not all HPET implementations are equal”", h2))
story.append(Paragraph("A moderator on the TechPowerUp thread you sent makes the right caveat, and it is independently supported: HPET frequency and "
    "quality vary by chipset. The HPET spec only mandates ≥10&nbsp;MHz; real parts report 14.318, 15, ~18, or 24&nbsp;MHz, and some have known bugs "
    "(the Linux kernel blacklisted HPET on certain Intel Coffee&nbsp;Lake parts for instability). This is exactly why a fixed “HPET = 14.318&nbsp;MHz” "
    "rule is wrong, and why your on-rig measurement - not a table - is the proof. " + tier_badge("T3"), bodyL))

# ================= 7. QPF DECODE =================
story.append(PageBreak())
story.append(Paragraph("7 · Reading the current source: QueryPerformanceFrequency decode", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(callout("USE THIS AS AN INDICATOR, NOT PROOF",
    "Microsoft: “Often QueryPerformanceFrequency doesn't return the actual frequency of the hardware tick generator … the performance counter "
    "frequency is fixed to 10&nbsp;MHz [on newer Windows] … <b>don't assume that QueryPerformanceFrequency will return a value derived from the "
    "hardware frequency.</b>” " + tier_badge("T1") + " So QPF narrows it down; the read-cost benchmark (§11) is the actual proof.", AMBER))
qpf = [[cell("QPF value", th), cell("Most likely source", th), cell("Notes", th)],
       [cell("10,000,000 (10 MHz)", tdc), cell("TSC path (modern Windows virtualised value) - or hypervisor", td),
        cell("On modern bare-metal Win10/11 this is what you see on the fast TSC path. Not unique to TSC by spec, so confirm with read cost.", td)],
       [cell("3,579,545 (3.58 MHz)", tdc), cell("ACPI PM timer (platform)", td), cell("Standardised, fixed frequency.", td)],
       [cell("14,318,180 (14.318 MHz)", tdc), cell("HPET (platform)", td), cell("Common HPET value, but not the only one.", td)],
       [cell("~15 / ~18 / 24 MHz etc.", tdc), cell("HPET (platform), chipset-dependent", td), cell("HPET frequency varies by implementation - do not hard-code it.", td)],
       [cell("1-4 GHz range", tdc), cell("Raw TSC frequency (older QPC behaviour)", td), cell("Rare on modern Windows; historical.", td)]]
story.append(table(qpf, [34*mm, 62*mm, 81*mm]))
story.append(Spacer(1,4))
story.append(Paragraph("Practical rule for the video: read QPF <b>and</b> <font name='DJM'>bcdedit /enum</font> to see what is forced, then let the "
    "read-cost benchmark deliver the verdict. If ns/call jumps from tens of ns to hundreds/1000, you are on a platform timer - that is the proof, "
    "regardless of what any single indicator says.", bodyL))

# ================= 8. APPLICABILITY GATE =================
story.append(Paragraph("8 · Applicability gate - will each knob even do anything?", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("Before designing a test you must know whether the knob can physically act on the rig; testing an inert knob manufactures "
    "false positives. Verdicts below assume a modern x64 gaming PC with an <b>invariant TSC</b> and <b>HPET present in firmware</b>. These verdicts are our engineering assessments from the documented mechanism (Section 5), not vendor statements - your measurement confirms them.", bodyL))
ag = [[cell("Knob", th), cell("Verdict", th), cell("What it does / expected effect category", th)],
      [cell("useplatformclock yes", tdb), cell("<font color='%s'><b>APPLICABLE</b></font>" % GREEN.hexval(), td),
       cell("Forces QPC onto HPET/PM. It <b>does</b> change behaviour - so the measured delta is real, not noise - but the direction is negative: higher read cost, no FPS gain. This is the primary test.", td)],
      [cell("disabledynamictick yes", tdb), cell("<font color='%s'><b>APPLICABLE</b></font>" % GREEN.hexval(), td),
       cell("Restores periodic kernel ticks. Real effect on wakeups/power and timer-interrupt count; <b>no</b> expected FPS benefit. Secondary myth.", td)],
      [cell("useplatformtick yes", tdb), cell("<font color='%s'><b>APPLICABLE</b></font>" % GREEN.hexval(), td),
       cell("Forces the OS tick onto a platform source, forbids synthetic timers. Real effect on tick backing/overhead; no expected FPS benefit.", td)],
      [cell("tscsyncpolicy", tdb), cell("<font color='%s'><b>CONDITIONAL → likely INERT</b></font>" % AMBER.hexval(), td),
       cell("Affects boot-time TSC sync/validation on multi-domain systems, not the steady-state read path on a single-socket invariant-TSC desktop. Appendix only; expect no gaming delta.", td)]]
story.append(table(ag, [40*mm, 44*mm, 93*mm]))
story.append(Spacer(1,4))
story.append(Paragraph("Branch conditions that flip useplatformclock away from APPLICABLE", h3))
story.append(bullets([
    "<b>No invariant TSC</b> (very old/exotic CPU): Windows is already on a platform timer, so forcing it changes nothing → <b>INERT</b>. Detect with "
    "Coreinfo <font name='DJM'>TSC-INVARIANT</font> or CPUID <font name='DJM'>80000007h:EDX[8]</font>. " + tier_badge("T1"),
    "<b>HPET disabled in BIOS:</b> <font name='DJM'>useplatformclock yes</font> may land on the PM timer instead of HPET, or not switch as expected → "
    "<b>CONDITIONAL</b>; verify the actual QPF/read-cost after reboot.",
    "<b>Already on a platform timer</b> for any reason → <b>INERT</b>.",
]))
story.append(callout("INTEGRITY NOTE",
    "Because <font name='DJM'>useplatformclock</font> is APPLICABLE on your target rig, a measured before/after delta is <b>real</b> and worth "
    "filming - it is not a false positive. The value of the video is showing that the real change is a <i>regression</i>.", GREEN))

# ---- 8.1 tscsyncpolicy deep-dive (for the future video) ----
story.append(PageBreak())
story.append(Paragraph("8.1 · Special case - tscsyncpolicy (groundwork for your future video)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("You plan a dedicated video and asked whether there are really four distinct values and how it benefits the PC. Here is the "
    "evidence-graded answer, separating what Microsoft documents from what forums assert.", bodyL))
story.append(Paragraph("What is documented (T1)", h3))
story.append(bullets([
    "The option is <font name='DJM'>tscsyncpolicy [ Default | Legacy | Enhanced ]</font> - “Controls the time stamp counter synchronization "
    "policy. This option should only be used for debugging.” That is the <i>entire</i> official description; Microsoft does not elaborate on Legacy "
    "vs Enhanced behaviour. " + tier_badge("T1"),
    "Context that pins the mechanism: TSC synchronization is a <b>boot-time</b> step - “During system initialization, Windows … performs the "
    "necessary frequency calibration and core synchronization,” and the Windows&nbsp;8 “TSC synchronization algorithm was significantly improved to "
    "better accommodate large systems with many processors.” " + tier_badge("T1"),
    "So the reasonable reading: <b>Legacy</b> = the older (pre-Win8) sync algorithm, <b>Enhanced</b> = the improved algorithm, <b>Default</b> = let "
    "Windows choose. It governs how per-core TSCs are aligned <i>at startup</i> - not the per-call read path.",
]))
story.append(callout("THE INTEGRITY-CRITICAL POINT",
    "tscsyncpolicy acts on <b>boot-time cross-core TSC synchronization</b>, not on the steady-state QPC read (which is still a single RDTSC). There "
    "is therefore <b>no documented mechanism</b> by which it would change per-frame FPS or input lag on a single-socket, invariant-TSC desktop. Any "
    "“FPS/latency” difference a user reports is, until proven otherwise, run-to-run noise or placebo. This makes it the <b>highest false-positive-risk "
    "tweak</b> in the whole set. (This is our reasoned inference from the documented facts above, not a Microsoft statement - your measurement is what settles it.)", RED))
story.append(Paragraph("The two claims you flagged", h3))
tsc = [[cell("Claim", th), cell("Evidence-based ruling", th)],
       [cell("“enhanced = Windows default; legacy = alternative” (your earlier video)", tdb),
        cell("<b>Unverified, and probably not accurate.</b> Microsoft lists a distinct <font name='DJM'>Default</font> token <i>separate</i> from "
             "<font name='DJM'>Enhanced</font>. That implies the default state is “Default / auto”, not specifically “enhanced.” The documented way to "
             "restore default is <font name='DJM'>/deletevalue</font>. Treat “enhanced = default” as " + tier_badge("T4") + " and correct it.", td)],
       [cell("“legacy = lower latency & lower FPS; enhanced = higher FPS & higher latency” (forums)", tdb),
        cell("<b>Anecdotal and internally inconsistent</b> across sources, with no documented mechanism linking a boot-time sync algorithm to "
             "steady-state frame timing. " + tier_badge("T4") + " - do not repeat as fact; put it on screen only as “a claim we are about to test.”", td)]]
story.append(table(tsc, [70*mm, 107*mm]))
story.append(Paragraph("Are there really four distinct values?", h3))
story.append(Paragraph("Documented tokens = <b>three</b>: Default, Legacy, Enhanced. Plus a fourth <i>state</i> - the unset baseline via "
    "<font name='DJM'>/deletevalue</font>. Whether the <font name='DJM'>Default</font> token behaves <b>differently</b> from the unset state is "
    "<b>not documented</b> and is likely identical. So “four distinct behaviours” is an open question - proving or disproving it is exactly what your "
    "future test should do, not assume.", bodyL))
story.append(Paragraph("Kernel-level evidence - the option was removed from the HAL", h3))
story.append(Paragraph("On <b>older</b> Windows builds the setting really did reach the kernel. Reverse-engineering read live in a kernel debugger "
    "(valleyofdoom/PC-Tuning) shows it setting the HAL variable <font name='DJM'>HalpTscSyncPolicy</font> to <b>0 for both "
    "<font name='DJM'>/deletevalue</font> and <font name='DJM'>default</font></b>, <b>1 for legacy</b> and <b>2 for enhanced</b>. So "
    "<font name='DJM'>default</font> and unset are the same value, and there are effectively <b>three</b> policies (0/1/2), not four. " + tier_badge("T3"), bodyL))
story.append(callout("DECISIVE UPDATE: ON CURRENT WINDOWS 11 BUILDS THE OPTION IS INERT",
    "Decompilation of the HAL boot-option parser from two builds side by side shows the branches "
    "<font name='DJM'>if (strstr(opts, &quot;TSCSYNCPOLICY=LEGACY&quot;)) HalpTscSyncPolicy = 1;</font> and the matching "
    "<font name='DJM'>=ENHANCED</font> branch present in the older build and <b>absent entirely</b> in the current Windows 11 build. Nothing in that "
    "parser reads the option any more. This matches the independent finding that the symbol <font name='DJM'>HalpTscSyncPolicy</font> no longer resolves "
    "in a kernel debugger on recent builds, and it matches our own measurement: the QPC read cost was identical (20.5 to 20.6 ns) across Default, Legacy "
    "and Enhanced.<br/><br/><b>Conclusion:</b> <font name='DJM'>bcdedit</font> still writes the value and <font name='DJM'>/enum</font> still displays it, "
    "but on current builds no code consumes it. Any FPS delta measured between these states is session drift, not the setting. " + tier_badge("T3") +
    " Three independent lines of evidence: decompiled parser, unresolved symbol, and zero measured change.", RED))
story.append(Paragraph("Scope of that conclusion: reverse-engineering shows the option is absent from the parser in the builds examined. Record the exact "
    "build numbers when citing it, and note that RE cannot prove absence across every future build. It is a well-supported conclusion, not a vendor "
    "statement; Microsoft documents neither the removal nor the behaviour.", bodyL))
story.append(Paragraph("Two more claims you will hear - and the sourced answer", h3))
kc = [[cell("Claim in circulation", th), cell("Evidence-based answer", th)],
      [cell("&ldquo;enhanced barely does anything on Windows 10&rdquo;", tdb),
       cell("<b>Broadly right, for the wrong reason.</b> On builds where the option still exists it does reach the kernel (enhanced sets HalpTscSyncPolicy=2), but it governs <b>boot-time TSC synchronisation</b>, not the per-read path, so a steady-state gaming effect was never expected. " + tier_badge("T3"), td)],
      [cell("&ldquo;enhanced doesn't work anymore on Windows 11&rdquo;", tdb),
       cell("<b>Supported on current builds.</b> The HAL parser branches that read TSCSYNCPOLICY are absent from the current Windows 11 build and present in the older one, the symbol no longer resolves, and our read-cost measurement showed no change. Earlier drafts of this document called this claim unsupported; that was based on the older build only and is <b>corrected here</b>. " + tier_badge("T3"), td)],
      [cell("&ldquo;on Windows 11 you cannot change it&rdquo;", tdb),
       cell("<b>Half right.</b> You can still write it: bcdedit accepts <font name='DJM'>/set tscsyncpolicy</font> and <font name='DJM'>/enum</font> shows it. What you cannot do on a current build is make it <i>act</i>, because nothing reads it. Note also that <font name='DJM'>default</font> equals <font name='DJM'>/deletevalue</font>. " + tier_badge("T1") + " " + tier_badge("T3"), td)]]
story.append(table(kc, [55*mm, 122*mm]))
story.append(Paragraph("Rigorous test plan for the future video", h3))
story.append(bullets([
    "States: (1) <font name='DJM'>/deletevalue tscsyncpolicy</font> [true baseline], (2) <font name='DJM'>/set tscsyncpolicy default</font>, "
    "(3) <font name='DJM'>legacy</font>, (4) <font name='DJM'>enhanced</font>. Reboot + <font name='DJM'>bcdedit /enum</font> verify after each.",
    "<b>Primary tell:</b> run the QPC read-cost benchmark in every state. Prediction: <b>no change</b> in ns/call - because the read path is untouched. "
    "If it is flat, that alone shows the timer cost is identical across all four, so any gaming delta is not coming from the timer.",
    "<b>Default-token vs unset test:</b> compare state (1) and (2). If <font name='DJM'>/enum</font> differs but read-cost and gaming medians are "
    "identical, they are functionally the same → not four distinct behaviours.",
    "<b>Gaming runs: more than the HPET test</b> (aim 7-10/state) because the expected effect is ~0, so the false-positive risk is high. Compare "
    "medians with CoV; reject anything inside noise.",
    "<b>What the policy actually governs:</b> optionally check QPC cross-core consistency/monotonicity (successive reads across cores) - that is the "
    "property TSC sync affects, far more than FPS.",
    "Apply the four-verdict framework (§12). The honest prior is <b>Neutral/Inconclusive for gaming</b>; let the data override it if it can.",
]))

# ================= 9. WHAT TO TEST =================
story.append(PageBreak())
story.append(Paragraph("9 · Exactly WHAT you will test - the state matrix", h1))
story.append(rule(BLUE, 1.4, 0, 8))
stm = [[cell("State", th), cell("BCD configuration", th), cell("What it isolates", th)],
       [cell("A · Clean Default", tdb), cell("/deletevalue all four options", tdc), cell("Windows auto-selection baseline (TSC on a healthy rig).", td)],
       [cell("B · Platform Clock", tdb), cell("useplatformclock yes", tdc), cell("The core HPET/platform-clock myth.", td)],
       [cell("C · Dynamic Tick off", tdb), cell("disabledynamictick yes", tdc), cell("Separate tick myth (wakeups/power).", td)],
       [cell("D · Platform Tick", tdb), cell("useplatformtick yes", tdc), cell("Platform-source forcing myth.", td)],
       [cell("E · Full Myth Pack", tdb), cell("B + C + D together", tdc), cell("The bundle forum “optimiser” scripts apply.", td)],
       [cell("F · Revert", tdb), cell("/deletevalue all four options", tdc), cell("Proves the baseline returns (reversibility).", td)]]
story.append(table(stm, [34*mm, 52*mm, 91*mm]))
story.append(Spacer(1,4))
story.append(Paragraph("Test order (detects drift and proves reversibility):", h3))
story.append(code("A → B → A → C → A → D → A → E → A → F"))
story.append(Paragraph("Returning to A between every change is what separates a real effect from thermal drift, a background process, or a "
    "“first-run vs later-run” artefact. A flat A→B→C→D→E sequence cannot do that.", bodyL))

# ================= 10. HOW TO TEST =================
story.append(Paragraph("10 · Exactly HOW you will test - commands, safety, verification", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("10.1 · Safety first (do this once, before anything)", h2))
story.append(bullets([
    "Run the console <b>elevated</b>. BCD edits need admin.",
    "Microsoft note: “Before setting BCDEdit options you might need to <b>disable or suspend BitLocker and Secure Boot</b>.” Have your BitLocker "
    "recovery key ready. " + tier_badge("T1"),
    "Back up BCD first - the helper tool does this automatically (<font name='DJM'>bcdedit /export</font>).",
    "<b>Reversibility, stated plainly:</b> these changes are <b>not</b> irreversible and do <b>not</b> require a Windows reinstall (a common forum "
    "myth). Undo with <font name='DJM'>/deletevalue</font> + reboot, or restore the backup with <font name='DJM'>bcdedit /import</font>.",
]))
story.append(code("mkdir C:\\AlchemyHPET\nbcdedit /export C:\\AlchemyHPET\\bcd-backup-before-tests.bcd\nbcdedit /enum {current} > C:\\AlchemyHPET\\bcd-before.txt"))
story.append(Paragraph("10.2 · Commands per state (canonical, from the docs)", h2))
story.append(Paragraph("Clean Default / Revert (states A and F):", h3))
story.append(code("bcdedit /deletevalue useplatformclock\nbcdedit /deletevalue useplatformtick\nbcdedit /deletevalue disabledynamictick\nbcdedit /deletevalue tscsyncpolicy\nshutdown /r /t 0"))
story.append(Paragraph("Platform Clock forced (state B):", h3))
story.append(code("bcdedit /set useplatformclock yes\nshutdown /r /t 0"))
story.append(Paragraph("Dynamic Tick disabled (state C) - clear the others first:", h3))
story.append(code("bcdedit /deletevalue useplatformclock\nbcdedit /deletevalue useplatformtick\nbcdedit /set disabledynamictick yes\nshutdown /r /t 0"))
story.append(Paragraph("Platform Tick forced (state D):", h3))
story.append(code("bcdedit /deletevalue useplatformclock\nbcdedit /deletevalue disabledynamictick\nbcdedit /set useplatformtick yes\nshutdown /r /t 0"))
story.append(Paragraph("Full Myth Pack (state E):", h3))
story.append(code("bcdedit /set useplatformclock yes\nbcdedit /set disabledynamictick yes\nbcdedit /set useplatformtick yes\nshutdown /r /t 0"))
story.append(callout("DOCS NUANCE",
    "Microsoft documents these values as <font name='DJM'>yes|no</font>. <font name='DJM'>true/false</font> are accepted aliases, but use "
    "<font name='DJM'>yes</font> to match the documentation exactly. And remember: the documented way back to default is <font name='DJM'>/deletevalue</font>, "
    "never <font name='DJM'>/set … no</font>.", BLUE))
story.append(Paragraph("10.3 · After every reboot, before measuring - verify the state actually changed", h2))
story.append(bullets([
    "“Command succeeded” is not proof. Confirm after reboot: <font name='DJM'>bcdedit /enum {current} &gt; bcd-state-[X].txt</font>.",
    "Capture QueryPerformanceFrequency and a quick QPC read-cost sample (the helper + benchmark tools do both).",
    "Record CPU/GPU clocks and temperature, and a background-process snapshot, so a hot or busy run is not mistaken for a timer effect.",
]))

# ================= 11. METRICS =================
story.append(PageBreak())
story.append(Paragraph("11 · Metrics & instrumentation (using your own capture tools)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("You already run deep latency/FPS capture, so this section defines <b>what to capture and how to read it honestly</b> rather than "
    "duplicating your tooling.", bodyL))
mt = [[cell("Tier", th), cell("Metric", th), cell("Why / how to read it", th)],
      [cell("PRIMARY", tdb), cell("QPC read cost: ns/call and calls/sec, single- and multi-thread", td),
       cell("The direct cost of the exact path <font name='DJM'>useplatformclock</font> changes. Least noisy, hardest to argue with. Multi-thread also exposes HPET's shared-resource scaling collapse. Use the included benchmark.", td)],
      [cell("SECONDARY", tdb), cell("ETW DPC/ISR duration & count by module", td),
       cell("Report faithfully: if it worsens, show it; if flat, say so; if variance is high, mark inconclusive. Do <b>not</b> claim Microsoft guarantees a DPC regression - it does not.", td)],
      [cell("TERTIARY", tdb), cell("Frametime P95/P99/P99.9, 1% & 0.1% lows, stutter count, GPU-busy/CPU-busy", td),
       cell("Practical relevance, not first proof. Use a repeatable CPU-bound scene where timer overhead can actually surface. Never rely on average FPS alone.", td)]]
story.append(table(mt, [26*mm, 60*mm, 91*mm]))
story.append(Spacer(1,4))
story.append(Paragraph("Run counts", h3))
story.append(bullets([
    "QPC read cost: 5 runs/state minimum (the benchmark defaults to 5; 7-10 if quick).",
    "ETW/DPC: at least one clean capture per state, repeated if variance is high.",
    "Gaming: 3 runs/state minimum, 5 preferred, identical scene and settings.",
]))
story.append(callout("THE ‘HPET BUG’ WORST CASE (mention, but as system-specific)",
    "On some affected systems, forced HPET does more than slow reads - the CPU cannot feed the GPU and GPU utilisation collapses "
    "(community/TimerBench reports show ~44% GPU load on HPET vs ~96% on TSC, with a large FPS loss). Present this as a <b>system-specific worst "
    "case</b> " + tier_badge("T4") + " that we neither confirm nor deny. If your rig shows it, film it; if it does not, say so plainly - the read-cost proof stands either way.", AMBER))

# ================= 12. STATS + VERDICT =================
story.append(Paragraph("12 · Statistics & the decision framework", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("For every metric compute: mean, median, min, max, standard deviation, coefficient of variation (CoV), and % delta vs the A "
    "baseline. <b>Compare on medians</b>; use mean as secondary; always state variance; reject any delta that sits inside normal run-to-run noise.", bodyL))
vf = [[cell("Verdict", th), cell("Trigger", th), cell("On-camera wording", th)],
      [cell("Reject / Harmful", tdb), cell("QPC read cost worsens AND no FPS/frametime/1%-low benefit", td),
       cell("“Forcing the platform clock raised timer-read overhead and produced no compensating gaming benefit. Reject as a gaming optimisation.”", td)],
      [cell("Neutral / Pointless", tdb), cell("Read cost worsens BUT gaming is statistically unchanged", td),
       cell("“The mechanism is measurably worse and there is no measured benefit - so it fails as an optimisation even though gaming doesn't collapse.”", td)],
      [cell("Conditional", tdb), cell("A specific broken/unstable platform actually improves", td),
       cell("“This is not a gaming tweak; it is a compatibility workaround for a specific broken timing platform.”", td)],
      [cell("Inconclusive", tdb), cell("High variance, weak runs, thermal drift, unstable reverts", td),
       cell("State it plainly and do not force a verdict from dirty data.", td)]]
story.append(table(vf, [34*mm, 60*mm, 83*mm]))

# ================= 13. WORDING RULES =================
story.append(PageBreak())
story.append(Paragraph("13 · Strict wording rules (say this / never say that)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
c1 = [Paragraph("<b>SAY (accurate)</b>", S("g", fontName="DJB", fontSize=8.6, textColor=GREEN))]
for t in ["“Windows uses the invariant TSC by default when it is suitable.”",
          "“If the TSC isn't suitable, Windows can auto-select HPET or the ACPI PM timer.”",
          "“Forcing the platform clock makes the timer slower to read - and it needs a kernel call.”",
          "“QueryPerformanceFrequency is an indicator of the source, not definitive proof.”",
          "“DPC and game results are measured here, not assumed.”",
          "“useplatformclock is a Microsoft-documented debugging option.”"]:
    c1.append(Paragraph("• "+t, S("gg", fontName="DJ", fontSize=8.4, textColor=TEXT, leading=12, spaceBefore=2)))
c2 = [Paragraph("<b>NEVER SAY (overreach)</b>", S("r", fontName="DJB", fontSize=8.6, textColor=RED))]
for t in ["“HPET is always bad.”",
          "“Windows 11 default is always TSC.”",
          "“QueryPerformanceFrequency alone proves the clock source.”",
          "“DPC latency always gets worse with HPET.”",
          "“You're literally running your whole PC in debug mode.”",
          "“BIOS HPET, Device Manager HPET and useplatformclock are the same thing.”",
          "“These bcdedit changes are irreversible / need a reinstall.”"]:
    c2.append(Paragraph("• "+t, S("rr", fontName="DJ", fontSize=8.4, textColor=TEXT, leading=12, spaceBefore=2)))
tw = Table([[c1, c2]], colWidths=[88.5*mm, 88.5*mm])
tw.setStyle(TableStyle([
    ("VALIGN",(0,0),(-1,-1),"TOP"),
    ("BACKGROUND",(0,0),(0,0), colors.HexColor("#EAF7EF")),
    ("BACKGROUND",(1,0),(1,0), colors.HexColor("#FBECEC")),
    ("LINEBEFORE",(0,0),(0,0),3, GREEN), ("LINEBEFORE",(1,0),(1,0),3, RED),
    ("LEFTPADDING",(0,0),(-1,-1),9),("RIGHTPADDING",(0,0),(-1,-1),9),
    ("TOPPADDING",(0,0),(-1,-1),8),("BOTTOMPADDING",(0,0),(-1,-1),8),
]))
story.append(tw)
story.append(Spacer(1,6))
story.append(Paragraph("Myths to correct explicitly on camera", h3))
story.append(bullets([
    "“useplatformclock true = more FPS / less input lag.” - False on modern hardware (the mechanism is slower). " + tier_badge("T1"),
    "“Disabling HPET in Device Manager disables HPET.” - False; it only removes the PnP node. " + tier_badge("T3"),
    "“These timer tweaks are irreversible.” - False; fully reversible via /deletevalue or /import. ",
    "“useplatformclock false is the clean default.” - Wrong; /deletevalue is. " + tier_badge("T1"),
    "“QPF proves the timer source.” - Incomplete; it can be fixed at 10&nbsp;MHz. " + tier_badge("T1"),
]))

# ================= 14. SCRIPT =================
story.append(PageBreak())
story.append(Paragraph("14 · Tightened video script (word-for-word)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("Titles (pick one)", h3))
story.append(bullets([
    "HPET for FPS Is Backwards - Here's the Measured Proof",
    "I Tested the “useplatformclock” Tweak. It Only Made the Clock Slower.",
    "The Most-Shared Windows Timer Tweak, Actually Measured",
]))
def beat(t, txt):
    story.append(Paragraph(t, h3))
    story.append(callout(None, txt, NAVY, GREYBG, NAVY))
beat("Hook (0:00-0:20)",
    "“One of the most-shared Windows tweaks tells you to force HPET - the ‘platform clock’ - for lower input lag and more FPS. I measured it "
    "directly. On a modern PC it does the opposite: it makes the timer your games rely on slower to read, and Windows even needs a kernel call to "
    "read it. Microsoft lists this setting as a <i>debugging</i> option. Let's prove it.”")
beat("What people believe (0:20-0:50)",
    "“The claim: flip a BIOS switch, disable a device, or run one bcdedit command, force HPET, and games get smoother. It's everywhere. The problem "
    "is it misunderstands what these timers do - and, as we'll see, two of those three ‘switches’ don't even do what people think.”")
beat("Mechanism (0:50-2:40)",
    "“Games ask Windows the time through an API called QueryPerformanceCounter. What answers it is a hardware timer. Modern CPUs have an invariant "
    "TSC - a counter inside the processor you can read in tens of cycles, in user mode, no kernel call. That's what Windows picks by default. HPET is "
    "an older, off-chip timer shared across all cores. Microsoft's own docs put a platform-timer read near a microsecond and say it needs a system "
    "call. That's not an optimisation - it's the fallback Windows uses only when the TSC is broken.”")
beat("The three switches (2:40-3:30)",
    "“Quick but important: BIOS HPET is real - it decides whether HPET exists for the OS. The bcdedit flag useplatformclock is real - it forces the "
    "platform clock. But disabling ‘High Precision Event Timer’ in Device Manager does <i>not</i> disable HPET: it only hides the PnP device; the "
    "kernel reaches HPET through an ACPI table and keeps using it. So most ‘disable HPET in Device Manager’ guides are doing nothing to the timer.”")
beat("Methodology (3:30-4:20)",
    "“Test rig: [CPU], Windows [build]. States: default, HPET forced, dynamic tick off, and all combined, reverting to default between each. My key "
    "measurement is direct - a loop that calls QueryPerformanceCounter millions of times and counts how many per second, single- and multi-threaded. "
    "That is the timer's read cost. Then DPC latency, frametime, 1% lows. Three to five runs each, and I reverted to confirm.”")
beat("Results (4:20-6:30)",
    "“Default, on the TSC: [MEASURE - ns/call, calls/sec]. Now HPET forced: [MEASURE - expect a large jump in ns/call and a multi-thread collapse]. "
    "That is the tweak making your clock slower to read, measured directly. DPC latency: [MEASURE - report exactly what you see]. Frametime and 1% "
    "lows: [MEASURE - report exactly what you see; may be unchanged]. Every number is from these runs.”")
beat("Verdict (6:30-7:20)",
    "“For a modern PC, forcing HPET is [tune to data - expected: worse-to-read with no FPS benefit]. It doesn't raise FPS; it makes the timer your "
    "games depend on slower and adds a kernel call. Its real home is fixing a genuinely broken TSC - a compatibility workaround, not a performance "
    "tweak.”")
beat("The fix + tool (7:20-8:10)",
    "“So what should you do? Nothing - leave the default. If you already set it, the fix is one command: bcdedit /deletevalue useplatformclock, "
    "reboot, done - and it's fully reversible, no reinstall. My helper shows the source you're actually on and reverts safely with a backup, because "
    "you shouldn't have to trust a forum post about your boot settings.”")
beat("Outro (8:10-end)",
    "“Default beats this ‘tweak’. Measured, not guessed. Next: the tweak this one gets confused with - Timer Resolution, the 0.5&nbsp;ms myth.”")

# ================= 15. SOURCE PACK =================
story.append(PageBreak())
story.append(Paragraph("15 · Verified source pack (audit with tiers)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
sp = [[cell("Claim", th), cell("Source", th), cell("Tier", th), cell("Verdict", th)],
      [cell("QPC is the primary high-resolution timestamp API", td), cell("MS Learn - Acquiring high-resolution time stamps", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("TSC read ≈ 10s-100s cycles; user-mode, no syscall", td), cell("MS Learn - same (QPC FAQ)", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("Platform-timer read ≈ 0.8-1.0 µs; needs a syscall", td), cell("MS Learn - QPC FAQ", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("HPET shared, higher latency, limits QPC scalability", td), cell("MS Learn - Hardware timer info", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("Windows auto-selects TSC, else HPET/PM, at init", td), cell("MS Learn - QPC support in Windows versions", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("useplatformclock / useplatformtick / disabledynamictick / tscsyncpolicy = “debugging only”", td), cell("MS Learn - BCDEdit /set", td), cell(tier_badge("T1"), tdb), cell("Verified (verbatim)", td)],
      [cell("/deletevalue removes an option (restore default); admin + possibly suspend BitLocker/Secure Boot", td), cell("MS Learn - BCDEdit /set, /deletevalue", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("QPF may be fixed at 10 MHz; not proof of source", td), cell("MS Learn - Low-level hardware clock characteristics", td), cell(tier_badge("T1"), tdb), cell("Verified (verbatim)", td)],
      [cell("Invariant TSC via Coreinfo / CPUID 80000007h:EDX[8]", td), cell("MS Learn - QPC FAQ; Intel/AMD", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("tscsyncpolicy: 3 tokens; governs boot-time TSC sync; debug-only", td), cell("MS Learn - BCDEdit /set; QPC (Win8 sync algorithm)", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("tscsyncpolicy sets HAL HalpTscSyncPolicy: deletevalue/default=0, legacy=1, enhanced=2 (older builds)", td), cell("valleyofdoom/PC-Tuning - research.md (kernel debugger)", td), cell(tier_badge("T3"), tdb), cell("Verified (independent RE); default==unset", td)],
      [cell("TSCSYNCPOLICY parser branches absent from the HAL on current Windows 11; option is inert there", td), cell("Decompiled HAL, two builds compared side by side; symbol unresolved in debugger", td), cell(tier_badge("T3"), tdb), cell("Verified (independent RE); corrects an earlier reading", td)],
      [cell("QPC/TSC/HPET selection unchanged Win8→10→11 (x64); knobs on both", td), cell("MS Learn - QPC support in Windows versions; BCDEdit /set", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("timeBeginPeriod per-process since Win10 2004; Win11 occlusion; does NOT affect QPC", td), cell("MS Learn - timeBeginPeriod (timeapi.h)", td), cell(tier_badge("T1"), tdb), cell("Verified (verbatim)", td)],
      [cell("10M reads: TSC ≈0.6 s, HPET ≈12 s, PM ≈24 s", td), cell("Red Hat MRG Realtime Reference Guide", td), cell(tier_badge("T2"), tdb), cell("Verified (corroborates read cost)", td)],
      [cell("HPET read ≈1-2 µs; spec doesn't require fast reads", td), cell("VMware - Timekeeping in VMware VMs", td), cell(tier_badge("T3"), tdb), cell("Verified (corroborates)", td)],
      [cell("HPET is MMIO, ACPI-discovered, min 10 MHz, off-chip", td), cell("Intel IA-PC HPET Specification 1.0a", td), cell(tier_badge("T1"), tdb), cell("Verified", td)],
      [cell("PNP0103 = HPET node in Device Manager", td), cell("Standard PnP ID registry; community (not MS-primary)", td), cell(tier_badge("T4"), tdb), cell("Standard ID; not MS-documented", td)],
      [cell("Disabling that node ≠ disabling HPET (kernel still uses it)", td), cell("Inference from MS ACPI/HAL docs + expert corroboration", td), cell(tier_badge("T3"), tdb), cell("Sound conclusion (not verbatim MS)", td)],
      [cell("tscsyncpolicy “enhanced=default” &amp; FPS/latency mappings", td), cell("Forums (Tom's HW, Blur Busters, scripts)", td), cell(tier_badge("T4"), tdb), cell("Not used as fact - contradictory", td)],
      [cell("“HPET bug”: GPU-load collapse on affected rigs", td), cell("TechPowerUp / TimerBench / overclockers.at", td), cell(tier_badge("T4"), tdb), cell("Directional only - system-specific", td)],
      [cell("“10-20% FPS from disabling HPET”; “24H2 smarter fallback”", td), cell("Blur Busters / XDA / blogs", td), cell(tier_badge("T4"), tdb), cell("Not used as fact - anecdotal", td)]]
story.append(table(sp, [63*mm, 55*mm, 12*mm, 47*mm], fs=7.7))
story.append(Spacer(1,3))
story.append(Paragraph("Roll-up: 13 Verified (T1) · 1 Verified (T2) · 4 Verified/sound (T3) · 4 directional-only (T4). Every load-bearing claim in the "
    "video is T1-T3; nothing rests on a T4 source.", small))
story.append(Paragraph("Primary URLs: learn.microsoft.com/windows/win32/sysinfo/acquiring-high-resolution-time-stamps · "
    "learn.microsoft.com/windows-hardware/drivers/devtest/bcdedit--set · "
    "learn.microsoft.com/windows-hardware/drivers/bringup/acpi-system-description-tables · "
    "intel.com IA-PC HPET Specification 1.0a", tiny))

# ================= 16. TOOLS =================
story.append(PageBreak())
story.append(Paragraph("16 · The two ready-to-run tools (included)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("16.1 · Measure-QpcReadCost.ps1 - the ‘money shot’", h2))
story.append(Paragraph("100% read-only, no admin, changes nothing. Compiles a tiny C# core (P/Invoke to QueryPerformanceCounter) and measures the "
    "real timer-read cost.", bodyL))
story.append(bullets([
    "Single-thread ns/call and calls/sec; multi-thread aggregate throughput and scaling efficiency (exposes HPET's shared-resource collapse).",
    "Prints QueryPerformanceFrequency with a decoded source hint; exports a CSV with per-run and summary rows (median/mean/min/max/CoV).",
    "Run it in each BCD state and compare state A vs B - the delta is your on-camera proof.",
]))
story.append(code("# per state, after reboot:\npowershell -ExecutionPolicy Bypass -File .\\Measure-QpcReadCost.ps1 -Label A_default -Repetitions 7\npowershell -ExecutionPolicy Bypass -File .\\Measure-QpcReadCost.ps1 -Label B_useplatformclock_yes -Repetitions 7"))
story.append(Paragraph("16.2 · Manage-HpetTestState.ps1 - safe apply/revert + source checker", h2))
story.append(bullets([
    "Always backs up BCD (<font name='DJM'>bcdedit /export</font>) before any change; refuses to run privileged actions without admin.",
    "Shows current state (QPF decode + parsed <font name='DJM'>bcdedit /enum</font>); applies A/B/C/D/E; reverts with <font name='DJM'>/deletevalue</font>.",
    "Warns if BitLocker is on; never reboots unless you pass <font name='DJM'>-Reboot</font> and confirm; prints the exact <font name='DJM'>/import</font> rollback command.",
]))
story.append(code("powershell -ExecutionPolicy Bypass -File .\\Manage-HpetTestState.ps1 -Action Status\npowershell -ExecutionPolicy Bypass -File .\\Manage-HpetTestState.ps1 -Action Apply -State PlatformClock\npowershell -ExecutionPolicy Bypass -File .\\Manage-HpetTestState.ps1 -Action Revert"))
story.append(callout("NOTE ON YOUR OWN TOOLING",
    "You said you already have deep latency/FPS capture, so this package deliberately does not duplicate ETW/DPC or frametime tools. Section 11 tells you "
    "exactly what to capture with them and how to read it without overclaiming. If you ever want a matching ETW DPC/ISR capture-and-parse helper or a "
    "stats workbook, they can be added.", BLUE))

# ================= 17. TAILORED APPENDIX =================
story.append(PageBreak())
story.append(Paragraph("17 &middot; Tailored appendix - applying this to YOUR rig", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("You chose &ldquo;master + tailored&rdquo;. The master protocol above is rig-agnostic. To lock the tailored applicability verdict I need a "
    "few specifics - fill the block below (the helper tool reads most of it automatically), then the decision tree gives your verdict.", bodyL))
story.append(Paragraph("Decision tree (produces your applicability verdict)", h3))
story.append(bullets([
    "<b>1. Invariant TSC?</b>  Run <font name='DJM'>Coreinfo.exe</font> and check <font name='DJM'>TSC-INVARIANT *</font> (or CPUID 80000007h:EDX[8]). "
    "If NO, useplatformclock is likely <b>INERT</b> (already on a platform timer); stop. If YES, continue.",
    "<b>2. HPET present/enabled in BIOS?</b>  If disabled, forcing may land on the PM timer or not switch, so <b>CONDITIONAL</b>; verify QPF/read-cost "
    "after reboot. If enabled, continue.",
    "<b>3. Current QPF near 10 MHz and low ns/call?</b>  Then you are on TSC now, and <font name='DJM'>useplatformclock yes</font> is <b>APPLICABLE</b> - "
    "the test is valid and the expected result is a regression. This is the normal case for a modern Windows 10 or 11 gaming PC (your notes target 25H2).",
]))
story.append(Paragraph("Metadata capture block (fill once, keep with the results)", h3))
meta = [[cell("Field", th), cell("Your value", th), cell("Field", th), cell("Your value", th)],
        [cell("CPU model", td), cell("", td), cell("GPU + driver", td), cell("", td)],
        [cell("Invariant TSC? (Coreinfo)", td), cell("", td), cell("HPET in BIOS?", td), cell("", td)],
        [cell("Motherboard + BIOS ver", td), cell("", td), cell("Windows build / KB", td), cell("", td)],
        [cell("QPF now (Hz)", td), cell("", td), cell("Power plan", td), cell("", td)],
        [cell("HAGS / VBS / Game Mode", td), cell("", td), cell("Monitor refresh", td), cell("", td)],
        [cell("Test title + scene", td), cell("", td), cell("Ambient / CPU temp", td), cell("", td)]]
story.append(table(meta, [38*mm, 50*mm, 38*mm, 51*mm]))
story.append(Spacer(1,4))
story.append(callout("TO FINALISE YOUR TAILORED VERDICT",
    "Send me your CPU, motherboard, GPU/driver, and whether HPET is enabled in BIOS (plus the <font name='DJM'>-Action Status</font> output). I'll "
    "return a locked INERT/APPLICABLE/CONDITIONAL verdict and, if you want, log this optimisation into your knowledgebase with the fixed schema.", BLUE))

# ================= 17.2 MELODY CROSS-CHECK =================
story.append(PageBreak())
story.append(Paragraph("17.2 · Community-source cross-check - Melody's Tweaks (timers)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(Paragraph("You asked how valid this page is. It is an individual/community resource (Google Sites), with <b>no primary citations and no "
    "published measurements</b>, so it is <b>" + tier_badge("T4") + "</b> as evidence. That said, it is noticeably more careful than the average tweak "
    "guide, and its <i>headline conclusions largely agree with our T1 findings</i> - most importantly that forcing a platform timer is not a latency "
    "win. Use its agreements as <b>convergent community support</b>; do not borrow its mechanism explanations, several of which are wrong.", bodyL))
mel = [[cell("Aligns with our T1 findings - worth stating (still T4)", th), cell("Wrong or overstated - do NOT repeat", th)],
       [cell("Forcing HPET/PMT is no gaming win; perceived latency gains are placebo or artifacts (CPU-bottleneck lowering GPU load; FPS-limiter misbehaving on TSC).", td),
        cell("&ldquo;TSC runs at ~3 MHz.&rdquo; <b>Wrong</b> - the TSC ticks near the CPU clock (GHz); ~3 MHz is closer to the PMT / a virtualised QPF value.", td)],
       [cell("All CPUs are affected, not just Intel or only AMD - &ldquo;test it yourself.&rdquo; (matches our integrity stance).", td),
        cell("&ldquo;HPET is slow because it is high-precision.&rdquo; <b>Wrong mechanism</b> - it is slow because it is off-chip MMIO and needs a kernel syscall (MS " + tier_badge("T1") + ").", td)],
       [cell("Leave HPET enabled in BIOS (it is the firmware lever and Windows' fallback).", td),
        cell("&ldquo;TSC periodically resyncs with HPET at the timer-resolution interval; clock-skew; anticheat speedhack.&rdquo; <b>Speculative</b>, not documented for an invariant TSC.", td)],
       [cell("PMT is ~3.58 MHz; HPET frequency varies (up to ~22 MHz). Melody's claim that some legacy games are timer-dependent (Saints Row 2, Source-engine caps) is plausible and testable - verify before asserting it.", td),
        cell("&ldquo;TSC is a synthetic timer.&rdquo; Non-standard/confusing wording - in Windows terms the <i>synthetic</i> timers are the ones useplatformtick forbids.", td)]]
story.append(table(mel, [88.5*mm, 88.5*mm], fs=7.9))
story.append(Spacer(1,5))
story.append(Paragraph("Good testable hypotheses it raises (worth adding to your matrix)", h3))
story.append(bullets([
    "Does <font name='DJM'>disabledynamictick</font> do anything when <font name='DJM'>useplatformtick yes</font> is set? Melody says no (the forced RTC tick is not dynamic). Add it as a sub-case and <b>measure</b> - a clean, cheap result.",
    "Test <b>HPET vs PMT vs RTC</b>, not only HPET vs TSC: PMT = HPET disabled in BIOS + <font name='DJM'>useplatformclock yes</font>; RTC = <font name='DJM'>useplatformtick yes</font>. Capture read-cost + frametime for each.",
    "<b>Legacy-game timer dependence</b> (Source-engine caps, Saints Row 2 speed bug) is a real, filmable counter-example - the honest &ldquo;when a platform timer <i>is</i> actually needed&rdquo; beat.",
    "Confirm &ldquo;perceived lower latency&rdquo; is a <b>CPU-bottleneck / GPU-load drop</b> by logging GPU-busy vs CPU-busy (already in your metrics) - this exposes the artifact on camera.",
    "8000&nbsp;Hz polling + platform timer stutter is testable if you have an 8K mouse; otherwise skip it rather than assert it.",
]))
story.append(callout("HOW TO CITE IT",
    "Reference Melody's Tweaks only as <b>convergent community reasoning</b> (" + tier_badge("T4") + ") for the conclusions that also carry T1 backing - "
    "never as the source for a mechanism. Its real value to your video: an independent tweaking resource that reaches the same skeptical conclusion "
    "you will prove with measurement - forcing platform timers is not a latency win.", BLUE))

# ================= 18. PRE-PUBLISH CHECKLIST =================
story.append(Paragraph("18 &middot; Pre-publish self-check (all must be true)", h1))
story.append(rule(BLUE, 1.4, 0, 8))
story.append(bullets([
    "Microsoft QPC + BCDEdit docs re-checked against the current OS build; no OS-specific behaviour change since.",
    "OS scope holds for Windows 10 & 11 (x64); every result records edition + build; dynamic-tick framed per-OS.",
    "BCD backed up; clean default uses /deletevalue, not /set no.",
    "Reboot performed and state re-verified (bcdedit /enum) after every change.",
    "QPC read cost measured single- and multi-thread; median-based comparison; CoV reported.",
    "DPC/ISR and gaming reported exactly as measured - no 'always worse' language.",
    "Revert confirmed and baseline A returned.",
    "Thumbnail claims match what the data actually shows (no un-measured 'worse' arrows).",
    "Wording avoids the six 'never say' lines; the three-switches correction is in.",
    "Every on-screen factual claim maps to a T1-T3 source in Section 15.",
]))
story.append(Spacer(1,6))
story.append(rule(NAVY, 1.2, 2, 6))
story.append(Paragraph("Bottom line: forcing the platform clock is a Microsoft-documented debugging override. On a healthy modern x64 Windows gaming PC "
    "it makes the timer slower to read (and adds a kernel call) with no gaming benefit. Leave Windows' auto-selection alone; remove any timer "
    "override with /deletevalue. Prove it on camera with the read-cost benchmark - measured, not assumed.", bodyL))
story.append(Spacer(1,4))
story.append(Paragraph("Prepared for Bill &middot; Alchemy Tweaks &middot; 03 Jul 2026 &middot; sources: Microsoft Learn, Intel IA-PC HPET Spec, Red Hat MRG, VMware, "
    "community (TechPowerUp/TimerBench, Blur Busters) graded by tier.", tiny))

# ---------- build ----------
doc = SimpleDocTemplate(OUT, pagesize=A4,
                        leftMargin=18*mm, rightMargin=18*mm, topMargin=15*mm, bottomMargin=16*mm,
                        title="Alchemy HPET Debunk - Master Verification & Production Package v2.0",
                        author="Alchemy Tweaks")
doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
print("WROTE", OUT, os.path.getsize(OUT), "bytes")
